import fs from 'node:fs';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { randomUUID } from 'node:crypto';

function dataRoot(projectRoot) {
  return path.join(projectRoot, 'data');
}

function importsRoot(projectRoot) {
  return path.join(dataRoot(projectRoot), 'imports');
}

export function ensureImportsDir(projectRoot) {
  fs.mkdirSync(importsRoot(projectRoot), { recursive: true });
}

export function slugify(text) {
  return String(text || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .replace(/-{2,}/g, '-');
}

function decodeXml(text) {
  return String(text || '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'");
}

function normalizeText(text) {
  return String(text || '')
    .replace(/\r/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function extractParagraphText(xmlParagraph) {
  return normalizeText(
    xmlParagraph
      .replace(/<w:tab\/>/g, '\t')
      .replace(/<w:br[^>]*\/>/g, '\n')
      .replace(/<w:cr\/>/g, '\n')
      .replace(/<w:t[^>]*>([\s\S]*?)<\/w:t>/g, '$1')
      .replace(/<\/w:p>/g, '\n')
      .replace(/<[^>]+>/g, '')
      .replace(/\t+/g, ' ')
      .replace(/[ ]{2,}/g, ' ')
      .trim()
  );
}

function extractDocxText(filePath) {
  const xml = execFileSync('/usr/bin/unzip', ['-p', filePath, 'word/document.xml'], {
    encoding: 'utf8',
    maxBuffer: 25 * 1024 * 1024
  });

  const paragraphs = xml.match(/<w:p[\s\S]*?<\/w:p>/g) || [];
  const text = paragraphs
    .map((paragraph) => decodeXml(extractParagraphText(paragraph)))
    .filter(Boolean)
    .join('\n\n');

  return normalizeText(text);
}

function extractTxtText(filePath) {
  return normalizeText(fs.readFileSync(filePath, 'utf8'));
}

export function extractTextFromFile(filePath, sourceFormat) {
  if (sourceFormat === 'docx') {
    return extractDocxText(filePath);
  }

  if (sourceFormat === 'txt') {
    return extractTxtText(filePath);
  }

  throw new Error(`Niet ondersteund bronformaat: ${sourceFormat}`);
}

function isTableHeader(line) {
  return /^(Frans|Nederlands|Voorbeeldzin|Jaar|Gebeurtenis|Regel|Voorbeelden?)$/i.test(line);
}

function isHeading(line) {
  const numberedHeading = /^(\d+\.\d+\s+\S|\d+\s+[A-Za-zÀ-ÿ]|§\s?\d+(\.\d+)?\s*\S)/;

  if (!line || line.length > 90 || isTableHeader(line)) {
    return false;
  }

  if (/^(Regel\s*\d*:?|Voorbeelden?:|Uitleg:|Voorbeeld(\s+\d+)?\s*:|Formule:|Bij een vergelijking)/i.test(line)) {
    return false;
  }

  if ((/[=×÷]/.test(line) || /^[-+*/]/.test(line)) && !numberedHeading.test(line)) {
    return false;
  }

  return (
    numberedHeading.test(line) ||
    /^(Jaartallen|Controleer jezelf|Kenmerkende aspecten|Begrippen|Meer woordenschat)\b/i.test(line) ||
    /^[A-ZÀ-Ý][^.!?]{0,88}$/.test(line)
  );
}

export function buildSuggestedSections(rawText, fallbackTitle) {
  const lines = normalizeText(rawText)
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);

  const sections = [];
  let current = null;

  lines.forEach((line) => {
    if (isHeading(line)) {
      if (current && current.bodyLines.length) {
        sections.push(current);
      }

      current = {
        heading: line,
        bodyLines: []
      };
      return;
    }

    if (!current) {
      current = {
        heading: fallbackTitle || 'Geimporteerde theorie',
        bodyLines: []
      };
    }

    current.bodyLines.push(line);
  });

  if (current && current.bodyLines.length) {
    sections.push(current);
  }

  if (!sections.length) {
    return [
      {
        heading: fallbackTitle || 'Geimporteerde theorie',
        body: normalizeText(rawText),
        position: 1
      }
    ];
  }

  return sections.map((section, index) => ({
    heading: section.heading,
    body: normalizeText(section.bodyLines.join('\n')),
    position: index + 1
  }));
}

export function parseMultipartForm(buffer, contentType) {
  const boundaryMatch = String(contentType || '').match(/boundary=([^;]+)/i);
  if (!boundaryMatch) {
    throw new Error('Geen multipart-boundary gevonden.');
  }

  const boundary = boundaryMatch[1];
  const delimiter = Buffer.from(`--${boundary}`);
  const parts = [];
  let cursor = 0;

  while (cursor < buffer.length) {
    const start = buffer.indexOf(delimiter, cursor);
    if (start === -1) {
      break;
    }

    const afterStart = start + delimiter.length;
    if (buffer.slice(afterStart, afterStart + 2).toString() === '--') {
      break;
    }

    const partStart = afterStart + 2;
    const headerEnd = buffer.indexOf(Buffer.from('\r\n\r\n'), partStart);
    if (headerEnd === -1) {
      break;
    }

    const headersRaw = buffer.slice(partStart, headerEnd).toString('utf8');
    const contentStart = headerEnd + 4;
    const nextBoundary = buffer.indexOf(Buffer.from(`\r\n--${boundary}`), contentStart);
    if (nextBoundary === -1) {
      break;
    }

    const content = buffer.slice(contentStart, nextBoundary);
    parts.push({ headersRaw, content });
    cursor = nextBoundary + 2;
  }

  const fields = {};
  let file = null;

  parts.forEach((part) => {
    const disposition = part.headersRaw.match(/content-disposition:\s*form-data;\s*name="([^"]+)"(?:;\s*filename="([^"]+)")?/i);
    if (!disposition) {
      return;
    }

    const name = disposition[1];
    const filename = disposition[2];
    const contentTypeMatch = part.headersRaw.match(/content-type:\s*([^\r\n]+)/i);
    const mimeType = contentTypeMatch?.[1] || 'application/octet-stream';

    if (filename) {
      file = {
        fieldName: name,
        filename,
        mimeType,
        buffer: part.content
      };
      return;
    }

    fields[name] = part.content.toString('utf8').trim();
  });

  return { fields, file };
}

export function storeUploadedFile(projectRoot, filename, buffer) {
  ensureImportsDir(projectRoot);
  const safeName = filename.replace(/[^a-zA-Z0-9._-]+/g, '-');
  const storedFilename = `${Date.now()}-${randomUUID()}-${safeName}`;
  const destination = path.join(importsRoot(projectRoot), storedFilename);
  fs.writeFileSync(destination, buffer);
  return {
    storedFilename,
    filePath: destination
  };
}

export function deleteStoredImportFile(projectRoot, storedFilename) {
  if (!storedFilename) {
    return;
  }

  const filePath = path.join(importsRoot(projectRoot), storedFilename);
  if (fs.existsSync(filePath)) {
    fs.unlinkSync(filePath);
  }
}
