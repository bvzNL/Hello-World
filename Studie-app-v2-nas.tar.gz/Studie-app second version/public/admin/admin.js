const adminAuthShell = document.getElementById('adminAuthShell');
const adminShell = document.getElementById('adminShell');
const adminLoginForm = document.getElementById('adminLoginForm');
const adminLoginFeedback = document.getElementById('adminLoginFeedback');
const adminLogoutButton = document.getElementById('adminLogoutButton');
const adminSessionLabel = document.getElementById('adminSessionLabel');
const catalogEl = document.getElementById('adminCatalog');
const importsCatalogEl = document.getElementById('importsCatalog');
const importFeedbackEl = document.getElementById('importFeedback');

const importForm = document.getElementById('importForm');
const subjectForm = document.getElementById('subjectForm');
const moduleForm = document.getElementById('moduleForm');
const theoryForm = document.getElementById('theoryForm');
const questionForm = document.getElementById('questionForm');

let catalog = [];
let imports = [];

async function api(pathname, options = {}) {
  const headers = options.body instanceof FormData
    ? {}
    : { 'Content-Type': 'application/json' };

  const response = await fetch(pathname, {
    headers,
    credentials: 'same-origin',
    ...options
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Onbekende fout' }));
    if ((response.status === 401 || response.status === 403) && pathname !== '/api/auth/login') {
      setAdminLoggedOut('Je sessie is verlopen of je hebt geen toegang meer.');
    }
    const message = new Error(error.error || 'Onbekende fout');
    message.status = response.status;
    throw message;
  }

  return response.json();
}

function setAdminLoggedIn(user) {
  adminAuthShell.classList.add('hidden');
  adminShell.classList.remove('hidden');
  adminSessionLabel.textContent = `${user.displayName} · beheerder`;
}

function setAdminLoggedOut(message = 'Log in om het beheer te openen.') {
  adminAuthShell.classList.remove('hidden');
  adminShell.classList.add('hidden');
  adminLoginFeedback.textContent = message;
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function optionMarkup(items, labelKey = 'title') {
  return items.map((item) => `<option value="${item.id}">${item[labelKey]}</option>`).join('');
}

function allModules() {
  return catalog.flatMap((subject) => subject.modules.map((module) => ({
    ...module,
    subjectTitle: subject.title
  })));
}

function updateSelects() {
  const subjectOptions = optionMarkup(catalog);
  importForm.subjectId.innerHTML = subjectOptions;
  moduleForm.subjectId.innerHTML = subjectOptions;

  const moduleOptions = allModules()
    .map((module) => `<option value="${module.id}">${module.subjectTitle} · ${module.title}</option>`)
    .join('');

  theoryForm.moduleId.innerHTML = moduleOptions;
  questionForm.moduleId.innerHTML = moduleOptions;
}

function renderImports() {
  if (!imports.length) {
    importsCatalogEl.className = 'admin-catalog empty-state';
    importsCatalogEl.textContent = 'Nog geen imports beschikbaar.';
    return;
  }

  importsCatalogEl.className = 'admin-catalog';
  importsCatalogEl.innerHTML = imports.map((item) => {
    const previewText = escapeHtml(item.rawText.slice(0, 900));
    const sectionsMarkup = item.suggestedSections.slice(0, 6).map((section) => `
      <div class="admin-subitem">
        <strong>${escapeHtml(section.heading)}</strong>
        <span>${escapeHtml(section.body.slice(0, 120))}${section.body.length > 120 ? '…' : ''}</span>
      </div>
    `).join('');

    return `
      <section class="card import-card">
        <div class="card-head">
          <h3>${escapeHtml(item.title)}</h3>
          <p>${escapeHtml(item.subjectTitle)} · ${escapeHtml(item.originalFilename)}</p>
        </div>
        <div class="admin-module-meta">
          <span>formaat: ${escapeHtml(item.sourceFormat)}</span>
          <span>status: ${escapeHtml(item.status)}</span>
          <span>${item.suggestedSections.length} theorieblokken</span>
        </div>
        <div class="import-preview">
          <strong>Tekstpreview</strong>
          <pre>${previewText}</pre>
        </div>
        <div class="admin-subitems">
          ${sectionsMarkup}
        </div>
        <div class="admin-actions">
          <button
            type="button"
            class="action-button"
            data-commit-import="${item.id}"
            ${item.status === 'imported' ? 'disabled' : ''}
          >
            ${item.status === 'imported' ? 'Al geimporteerd' : 'Importeer als theorie'}
          </button>
          <button type="button" class="action-button secondary" data-delete-import="${item.id}">
            Verwijder import
          </button>
        </div>
      </section>
    `;
  }).join('');

  importsCatalogEl.querySelectorAll('[data-commit-import]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await api(`/api/admin/imports/${button.dataset.commitImport}/commit`, {
          method: 'POST',
          body: JSON.stringify({})
        });
        importFeedbackEl.textContent = 'Import is omgezet naar een theorie-module.';
        await refreshAll();
      } catch (error) {
        importFeedbackEl.textContent = `Importeren mislukt: ${error.message}`;
      }
    });
  });

  importsCatalogEl.querySelectorAll('[data-delete-import]').forEach((button) => {
    button.addEventListener('click', async () => {
      try {
        await api(`/api/admin/imports/${button.dataset.deleteImport}`, { method: 'DELETE' });
        importFeedbackEl.textContent = 'Import verwijderd.';
        await loadImports();
      } catch (error) {
        importFeedbackEl.textContent = `Verwijderen mislukt: ${error.message}`;
      }
    });
  });
}

function renderCatalog() {
  if (!catalog.length) {
    catalogEl.className = 'admin-catalog empty-state';
    catalogEl.textContent = 'Nog geen inhoud aanwezig.';
    return;
  }

  catalogEl.className = 'admin-catalog';
  catalogEl.innerHTML = catalog.map((subject) => `
    <section class="card admin-subject-card">
      <div class="card-head">
        <h3>${escapeHtml(subject.title)}</h3>
        <p>${escapeHtml(subject.description)}</p>
      </div>
      <div class="admin-subject-meta">
        <span class="topic-chip">${escapeHtml(subject.slug)}</span>
      </div>
      <div class="admin-module-list">
        ${subject.modules.map((module) => `
          <article class="admin-module">
            <header>
              <strong>${escapeHtml(module.title)}</strong>
              <span class="topic-chip">${escapeHtml(module.type)}</span>
            </header>
            <p>${escapeHtml(module.summary)}</p>
            <div class="admin-module-meta">
              <span>topic: ${escapeHtml(module.topic)}</span>
              <span>${module.theorySections.length} theorieblokken</span>
              <span>${module.questions.length} vragen</span>
            </div>
            <div class="admin-actions">
              <button type="button" class="action-button danger-button" data-delete-module="${module.id}">Verwijder module</button>
            </div>
            <div class="admin-subitems">
              ${module.theorySections.map((section) => `
                <div class="admin-subitem">
                  <strong>Theorie:</strong> ${escapeHtml(section.heading)}
                  <button type="button" class="mini-button" data-delete-theory="${section.id}">Verwijder</button>
                </div>
              `).join('')}
              ${module.questions.map((question) => `
                <div class="admin-subitem">
                  <strong>Vraag:</strong> ${escapeHtml(question.prompt)}
                  <button type="button" class="mini-button" data-delete-question="${question.id}">Verwijder</button>
                </div>
              `).join('')}
            </div>
          </article>
        `).join('')}
      </div>
      <div class="admin-actions">
        <button type="button" class="action-button danger-button" data-delete-subject="${subject.id}">Verwijder vak</button>
      </div>
    </section>
  `).join('');

  catalogEl.querySelectorAll('[data-delete-subject]').forEach((button) => {
    button.addEventListener('click', () => deleteItem(`/api/admin/subjects/${button.dataset.deleteSubject}`));
  });

  catalogEl.querySelectorAll('[data-delete-module]').forEach((button) => {
    button.addEventListener('click', () => deleteItem(`/api/admin/modules/${button.dataset.deleteModule}`));
  });

  catalogEl.querySelectorAll('[data-delete-theory]').forEach((button) => {
    button.addEventListener('click', () => deleteItem(`/api/admin/theory-sections/${button.dataset.deleteTheory}`));
  });

  catalogEl.querySelectorAll('[data-delete-question]').forEach((button) => {
    button.addEventListener('click', () => deleteItem(`/api/admin/questions/${button.dataset.deleteQuestion}`));
  });
}

async function loadCatalog() {
  catalog = await api('/api/admin/catalog');
  renderCatalog();
  updateSelects();
}

async function loadImports() {
  imports = await api('/api/admin/imports');
  renderImports();
}

async function refreshAll() {
  await Promise.all([loadCatalog(), loadImports()]);
}

function parseOptions(text) {
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean);
}

async function deleteItem(pathname) {
  await api(pathname, { method: 'DELETE' });
  await refreshAll();
}

importForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = new FormData(importForm);
  const file = data.get('sourceFile');
  if (!(file instanceof File) || !file.name) {
    importFeedbackEl.textContent = 'Kies eerst een `.docx` of `.txt` bestand.';
    return;
  }

  data.set('sourceFile', file, file.name);

  try {
    await api('/api/admin/imports', {
      method: 'POST',
      body: data
    });
    importFeedbackEl.textContent = `Upload gelukt: ${file.name} is geanalyseerd.`;
    importForm.reset();
    await refreshAll();
  } catch (error) {
    importFeedbackEl.textContent = `Upload mislukt: ${error.message}`;
  }
});

subjectForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = new FormData(subjectForm);
  await api('/api/admin/subjects', {
    method: 'POST',
    body: JSON.stringify(Object.fromEntries(data))
  });
  subjectForm.reset();
  await refreshAll();
});

moduleForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(moduleForm));
  data.position = Number(data.position || 0);
  await api('/api/admin/modules', {
    method: 'POST',
    body: JSON.stringify(data)
  });
  moduleForm.reset();
  await refreshAll();
});

theoryForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(theoryForm));
  data.position = Number(data.position || 0);
  await api('/api/admin/theory-sections', {
    method: 'POST',
    body: JSON.stringify(data)
  });
  theoryForm.reset();
  await refreshAll();
});

questionForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(questionForm));
  data.options = parseOptions(data.options || '');
  data.difficulty = Number(data.difficulty || 2);
  await api('/api/admin/questions', {
    method: 'POST',
    body: JSON.stringify(data)
  });
  questionForm.reset();
  await refreshAll();
});

adminLoginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(adminLoginForm));

  try {
    const payload = await api('/api/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        ...data,
        target: 'admin'
      })
    });

    setAdminLoggedIn(payload.user);
    adminLoginForm.reset();
    await refreshAll();
  } catch (error) {
    adminLoginFeedback.textContent = error.message;
  }
});

adminLogoutButton.addEventListener('click', async () => {
  await api('/api/auth/logout', {
    method: 'POST',
    body: JSON.stringify({})
  });

  setAdminLoggedOut('Je bent uitgelogd.');
});

async function initializeAdmin() {
  const session = await api('/api/auth/session');

  if (!session.user) {
    setAdminLoggedOut();
    return;
  }

  if (session.user.role !== 'admin') {
    setAdminLoggedOut('Dit account heeft geen toegang tot het beheer.');
    return;
  }

  setAdminLoggedIn(session.user);
  await refreshAll();
}

initializeAdmin().catch((error) => {
  if (error.status === 401 || error.status === 403) {
    setAdminLoggedOut(error.message);
    return;
  }

  catalogEl.className = 'admin-catalog empty-state';
  catalogEl.textContent = `Beheer laden mislukt: ${error.message}`;
  importsCatalogEl.className = 'admin-catalog empty-state';
  importsCatalogEl.textContent = `Imports laden mislukt: ${error.message}`;
});
