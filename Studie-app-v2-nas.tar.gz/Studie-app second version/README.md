# Studie-app second version

Deze map bevat een nieuwe lokale basis voor een versie van de Studie-app met:

- een backend API
- een SQLite-database
- een responsieve frontend
- adaptieve selectie van oefen- en toetsvragen
- een beheerinterface voor vakken, modules, theorie en vragen

## Lokale start

1. Installeer dependencies:

```bash
npm install
```

2. Start de app lokaal:

```bash
npm run db:seed
npm run dev
```

3. Open daarna:

```text
http://localhost:3000
```

4. Open de beheerinterface via:

```text
http://localhost:3000/admin/index.html
```

## Inloggen

Standaard worden bij het initialiseren twee accounts aangemaakt:

- leerling: `leerling` / `Leerling123!`
- beheerder: `admin` / `Admin123!`

Pas deze gegevens voor productie of NAS-gebruik aan via omgevingsvariabelen zoals in [.env.example](/Users/bartvanderzwan/Studie-App/Studie-app%20second%20version/.env.example).

## Structuur

- `server/index.js`: Express-server en API-routes
- `server/db.js`: database-initialisatie en schema
- `server/adaptive.js`: logica voor adaptieve vraagselectie
- `server/imports.js`: tekstextractie en importlogica voor `.docx` en `.txt`
- `public/`: frontend
- `public/admin/`: beheerinterface
- `data/`: lokale SQLite-database

De huidige lokale database bevat al de gemigreerde inhoud voor Frans, Wiskunde en Geschiedenis.

## Importworkflow

Via de beheerinterface kun je nu `.docx`- en `.txt`-bestanden uploaden als bronmateriaal.
De server extraheert daaruit tekst, maakt voorlopige theorieblokken en laat die eerst als preview zien.
Pas daarna zet je een import om naar een echte theorie-module in de database.

## Databaseflow

De database-inhoud is nu reproduceerbaar via scripts:

```bash
npm run db:export
npm run db:import
npm run db:seed
```

- `db:export` schrijft de actuele inhoud weg naar `seeds/base-seed.json`
- `db:import` leest een seedbestand in en vervangt de inhoudstabellen
- `db:seed` vult een lege of nieuwe omgeving met de basisinhoud uit `seeds/base-seed.json`

## Naar een NAS brengen

Voor een eerste netwerkversie op je NAS:

1. Zet de hele map op de NAS.
2. Maak een `.env` op basis van `.env.example` en kies eigen login-gegevens.
3. Installeer Node.js of gebruik Docker.
4. Start de app via Node.js of Docker.

Met Node.js:

```bash
npm install
npm run db:seed
npm start
```

Met Docker Compose:

```bash
docker compose up --build -d
docker exec studie-app-second-version npm run db:seed
```

5. Open daarna vanaf een apparaat in je netwerk:

```text
http://<nas-ip>:3000
```

Gebruik de beheerinterface alleen binnen je eigen netwerk zolang er nog geen extra beveiligingslaag of reverse proxy met HTTPS voor staat.

## Eerste ontwerpkeuzes

- Theorie staat als losse contentblokken in de database, zodat je makkelijk tekst kunt toevoegen, aanpassen of verwijderen.
- Vragen hebben metadata zoals `topic`, `difficulty` en `kind`, zodat adaptieve selectie mogelijk is.
- Pogingen worden opgeslagen in `attempts`; de backend gebruikt die historie om zwakke onderwerpen vaker terug te laten komen.
- De frontend is mobile-first opgezet, zodat later hosten op je NAS logisch blijft voor telefoon, tablet en desktop.
- De inhoud staat nu los van oude HTML-bestanden, zodat uitbreiding naar nieuwe vakken via de database kan verlopen.

## Volgende logische stappen

- adaptieve logica verfijnen met meer signalen, zoals tijd per vraag en recency
- bulk-import voor vragen uit CSV of Excel toevoegen
- per vak een eigen leerroute, niveaus en leerdoelen modelleren
- rollen en accountbeheer verder uitbreiden met wachtwoordwijzigingen en meerdere leerlingen
