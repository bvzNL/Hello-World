export function normalizeAnswer(answer) {
  return String(answer ?? '')
    .trim()
    .toLowerCase()
    .replace(/,/g, '.')
    .replace(/\s+/g, ' ');
}

function buildAttemptsIndex(attempts) {
  const byQuestion = new Map();
  const byTopic = new Map();

  for (const attempt of attempts) {
    const questionStats = byQuestion.get(attempt.question_id) || { total: 0, wrong: 0, correct: 0 };
    questionStats.total += 1;
    questionStats.correct += attempt.is_correct ? 1 : 0;
    questionStats.wrong += attempt.is_correct ? 0 : 1;
    byQuestion.set(attempt.question_id, questionStats);

    const topicStats = byTopic.get(attempt.topic) || { total: 0, wrong: 0 };
    topicStats.total += 1;
    topicStats.wrong += attempt.is_correct ? 0 : 1;
    byTopic.set(attempt.topic, topicStats);
  }

  return { byQuestion, byTopic };
}

export function chooseAdaptiveQuestion(questions, attempts) {
  if (!questions.length) {
    return null;
  }

  const { byQuestion, byTopic } = buildAttemptsIndex(attempts);

  const scored = questions.map((question) => {
    const questionStats = byQuestion.get(question.id) || { total: 0, wrong: 0 };
    const topicStats = byTopic.get(question.topic) || { total: 0, wrong: 0 };
    const topicWeakness = topicStats.total ? topicStats.wrong / topicStats.total : 0;
    const questionWeakness = questionStats.total ? questionStats.wrong / questionStats.total : 0;
    const freshnessBonus = questionStats.total === 0 ? 2 : 0;
    const difficultyWeight = Number(question.difficulty || 1) * 0.25;
    const score = 1 + freshnessBonus + (topicWeakness * 4) + (questionWeakness * 5) + difficultyWeight;

    return {
      question,
      score
    };
  });

  scored.sort((left, right) => right.score - left.score);
  const topBand = scored.slice(0, Math.min(3, scored.length));
  return topBand[Math.floor(Math.random() * topBand.length)].question;
}
