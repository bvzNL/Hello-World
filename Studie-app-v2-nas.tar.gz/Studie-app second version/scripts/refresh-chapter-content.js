import { initializeDatabase } from '../server/db.js';

const db = initializeDatabase();

function question({
  topic,
  kind = 'multiple_choice',
  prompt,
  explanation,
  difficulty = 2,
  correctAnswer,
  options = []
}) {
  return { topic, kind, prompt, explanation, difficulty, correctAnswer, options };
}

const chapterContent = [
  {
    moduleId: 31,
    summary: 'Chapitre 4: lichaam, sport en grammaire met partir/sortir en passe compose met etre.',
    sections: [
      {
        heading: 'Vocabulaire: corps et sport',
        body: `Belangrijke woorden uit chapitre 4 horen bij lichaam, sport en gezondheid. Denk aan le corps, les jambes, le dos, les bras en les genoux. Ook werkwoorden als bouger, courir, jouer au basket en faire de la natation horen bij dit thema.

De leerling moet deze woorden niet alleen herkennen, maar ook in een zin kunnen gebruiken. Voorbeelden zijn: Tu as mal au dos ?, L'athlete s'est blesse aux genoux en On va jouer au basket demain ?`
      },
      {
        heading: 'Meer woordenschat rond gezondheid en vrije tijd',
        body: `In dit hoofdstuk komen ook woorden terug die bij afspraken, trainen en motivatie horen, zoals le rendez-vous, le medecin, l'hopital, l'entrainement, les conseils, assez, au moins en ... fois par semaine.

Deze woorden helpen bij het spreken over gezond leven en sporten. Handige combinaties zijn s'inscrire a une competition, s'entrainer trois fois par semaine en etre en forme.`
      },
      {
        heading: 'Partir en sortir',
        body: `Partir betekent vertrekken. Sortir betekent uitgaan, naar buiten gaan of ergens uit komen. Deze werkwoorden worden vaak gebruikt om beweging en vertrek te beschrijven.

Voorbeelden: Le train va partir dans cinq minutes. Nous sortons du gymnase a midi. Let op dat de stam in sommige vormen verandert: je pars, tu pars, il part, nous partons, vous partez, ils partent.`
      },
      {
        heading: 'Passe compose met etre',
        body: `Sommige werkwoorden krijgen in de passe compose etre als hulpwerkwoord, bijvoorbeeld partir, sortir, entrer, rester en retourner.

Je schrijft dan: etre in de tegenwoordige tijd + voltooid deelwoord. Het voltooid deelwoord past zich aan aan onderwerp in geslacht en getal. Voorbeelden: Elle est partie. Ils sont restes. Malika est retournee au stade.`
      },
      {
        heading: 'A + lidwoord bij sport en plaats',
        body: `Na a smelt het lidwoord soms samen. Je krijgt au bij a + le, a la bij vrouwelijke woorden, a l' bij klinkerwoorden en aux bij meervoud.

Voorbeelden: aller au stade, jouer au basket, aller a la piscine, aller a l'hopital, faire attention aux genoux.`
      }
    ],
    questions: [
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Wat betekent le corps?',
        explanation: 'Le corps betekent het lichaam.',
        correctAnswer: 'het lichaam',
        options: ['het lichaam', 'de dokter', 'de training', 'de rug']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Welke Franse uitdrukking betekent "pijn hebben aan / in"?',
        explanation: 'Avoir mal a betekent pijn hebben aan of in iets.',
        correctAnswer: 'avoir mal a',
        options: ['etre en forme', 'avoir mal a', 'faire de son mieux', 'avoir raison']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Kies het juiste Franse woord voor "de afspraak".',
        explanation: 'Le rendez-vous betekent de afspraak.',
        correctAnswer: 'le rendez-vous',
        options: ['le champion', 'l\'hopital', 'le rendez-vous', 'les conseils']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Wat betekent s\'entrainer?',
        explanation: 'S\'entrainer betekent trainen.',
        correctAnswer: 'trainen',
        options: ['inschrijven', 'trainen', 'verminderen', 'teruggaan']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke vorm is correct bij nous?',
        explanation: 'Bij nous gebruik je nous partons.',
        correctAnswer: 'nous partons',
        options: ['nous partons', 'nous part', 'nous pars', 'nous partez']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke zin staat in de passe compose met etre?',
        explanation: 'Partir gebruikt etre in de passe compose: Elle est partie.',
        correctAnswer: 'Elle est partie.',
        options: ['Elle a partie.', 'Elle est partie.', 'Elle a sorti.', 'Elle est partir.']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke combinatie is correct?',
        explanation: 'A + le wordt au. Je zegt dus jouer au basket.',
        correctAnswer: 'jouer au basket',
        options: ['jouer a le basket', 'jouer au basket', 'jouer aux basket', 'jouer a la basket']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Vul aan: Ils ... restes a Paris.',
        explanation: 'Bij ils in de passe compose met etre schrijf je sont restes.',
        correctAnswer: 'sont',
        options: ['ont', 'sont', 'est', 'avez']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        kind: 'open',
        prompt: 'Vertaal naar het Frans: de dokter.',
        explanation: 'De dokter is le medecin.',
        correctAnswer: 'le medecin',
        difficulty: 2
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        kind: 'open',
        prompt: 'Vertaal naar het Nederlands: assez.',
        explanation: 'Assez betekent genoeg.',
        correctAnswer: 'genoeg',
        difficulty: 2
      }),
      question({
        topic: 'chapitre-4-grammaire',
        kind: 'open',
        prompt: 'Maak correct: a + les genoux = ?',
        explanation: 'A + les wordt aux: aux genoux.',
        correctAnswer: 'aux genoux',
        difficulty: 2
      }),
      question({
        topic: 'chapitre-4-grammaire',
        kind: 'open',
        prompt: 'Vul het hulpwerkwoord in: Nous ... sortis du stade.',
        explanation: 'Sortir krijgt in deze betekenis etre: Nous sommes sortis du stade.',
        correctAnswer: 'sommes',
        difficulty: 3
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke vertaling past bij "Ils sont retournes"?',
        explanation: 'Ils sont retournes betekent: zij zijn teruggekeerd.',
        correctAnswer: 'zij zijn teruggekeerd',
        options: ['zij keren terug', 'zij zijn teruggekeerd', 'zij zullen vertrekken', 'zij trainen']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Welke combinatie hoort bij vrije tijd?',
        explanation: 'Le temps libre betekent vrije tijd.',
        correctAnswer: 'le temps libre',
        options: ['le jeu de ballon', 'le temps libre', 'le corps', 'l\'ecran']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Wat is de juiste zin?',
        explanation: 'Je gaat naar het ziekenhuis: aller a l\'hopital.',
        correctAnswer: 'Je vais a l\'hopital.',
        options: ['Je vais au hopital.', 'Je vais a l\'hopital.', 'Je vais aux hopital.', 'Je vais a la hopital.']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke vorm van sortir past bij vous in de tegenwoordige tijd?',
        explanation: 'Bij vous gebruik je vous sortez.',
        correctAnswer: 'vous sortez',
        options: ['vous sortez', 'vous sortons', 'vous sors', 'vous sortent']
      })
    ]
  },
  {
    moduleId: 32,
    summary: 'Oefenvragen bij chapitre 4 over sport, gezondheid, partir/sortir en passe compose.',
    sections: [],
    questions: [
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Wat betekent les genoux?',
        explanation: 'Les genoux betekent de knieen.',
        correctAnswer: 'de knieen',
        options: ['de armen', 'de knieen', 'de rug', 'de benen']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Welke Franse uitdrukking betekent "fit zijn"?',
        explanation: 'Etre en forme betekent fit zijn.',
        correctAnswer: 'etre en forme',
        options: ['etre motive', 'etre en forme', 'avoir mal a', 'tomber malade']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Wat betekent le medecin?',
        explanation: 'Le medecin betekent de dokter.',
        correctAnswer: 'de dokter',
        options: ['de dokter', 'het ziekenhuis', 'de training', 'de afspraak']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Vertaal: jouer au basket.',
        explanation: 'Jouer au basket betekent basketballen.',
        correctAnswer: 'basketballen',
        kind: 'open'
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Wat betekent au moins?',
        explanation: 'Au moins betekent minstens.',
        correctAnswer: 'minstens',
        options: ['ongeveer', 'minstens', 'genoeg', 'dus']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Kies de juiste vorm: je ... (partir)',
        explanation: 'Bij je hoort je pars.',
        correctAnswer: 'pars',
        options: ['pars', 'partons', 'partez', 'partent']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke zin gebruikt etre correct?',
        explanation: 'Met sortir en partir gebruik je vaak etre in de passe compose.',
        correctAnswer: 'Nous sommes sortis.',
        options: ['Nous avons sortis.', 'Nous sommes sortis.', 'Nous avons sorti.', 'Nous etes sortis.']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Maak af: a + les = ?',
        explanation: 'A + les wordt aux.',
        correctAnswer: 'aux',
        kind: 'open'
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Welke combinatie klopt?',
        explanation: 'A + le wordt au.',
        correctAnswer: 'au',
        options: ['a le', 'a la', 'au', 'aux']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Wat betekent remplir?',
        explanation: 'Remplir betekent invullen.',
        correctAnswer: 'invullen',
        options: ['aanmoedigen', 'invullen', 'verminderen', 'trainen']
      }),
      question({
        topic: 'chapitre-4-vocabulaire',
        prompt: 'Welke uitdrukking betekent "gelijk hebben"?',
        explanation: 'Avoir raison betekent gelijk hebben.',
        correctAnswer: 'avoir raison',
        options: ['avoir lieu', 'avoir raison', 'faire de son mieux', 'rester']
      }),
      question({
        topic: 'chapitre-4-grammaire',
        prompt: 'Vul in: Elles sont ... au stade. (retourner)',
        explanation: 'Het voltooid deelwoord is retournees.',
        correctAnswer: 'retournees',
        kind: 'open',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 33,
    summary: 'Toetsvragen bij chapitre 4 over woordenschat, sport en de grammatica van het hoofdstuk.',
    sections: [],
    questions: [
      question({
        topic: 'chapitre-4-toets',
        prompt: 'Wat betekent l\'entrainement?',
        explanation: 'L\'entrainement betekent de training.',
        correctAnswer: 'de training',
        difficulty: 3,
        options: ['de training', 'de afspraak', 'de dokter', 'de kampioen']
      }),
      question({
        topic: 'chapitre-4-toets',
        prompt: 'Welke zin is grammaticaal correct?',
        explanation: 'Partir krijgt etre: Elles sont parties.',
        correctAnswer: 'Elles sont parties a huit heures.',
        difficulty: 3,
        options: ['Elles ont parties a huit heures.', 'Elles sont parties a huit heures.', 'Elles sont partir a huit heures.', 'Elles ont partir a huit heures.']
      }),
      question({
        topic: 'chapitre-4-toets',
        prompt: 'Hoe zeg je "basketballen" in het Frans?',
        explanation: 'Jouer au basket betekent basketballen.',
        correctAnswer: 'jouer au basket',
        difficulty: 2,
        options: ['faire du basket', 'jouer au basket', 'jouer a basket', 'faire a la natation']
      }),
      question({
        topic: 'chapitre-4-toets',
        prompt: 'Kies de juiste combinatie: a + le stade',
        explanation: 'A + le wordt au, dus au stade.',
        correctAnswer: 'au stade',
        difficulty: 2,
        options: ['a le stade', 'aux stade', 'au stade', 'a la stade']
      }),
      question({
        topic: 'chapitre-4-toets',
        kind: 'open',
        prompt: 'Vertaal naar het Frans: Zij zijn fit.',
        explanation: 'Je zegt: Ils sont en forme.',
        correctAnswer: 'ils sont en forme',
        difficulty: 3
      }),
      question({
        topic: 'chapitre-4-toets',
        kind: 'open',
        prompt: 'Vul aan: Je ... du gymnase a cinq heures. (sortir)',
        explanation: 'Bij je hoort je sors.',
        correctAnswer: 'sors',
        difficulty: 3
      }),
      question({
        topic: 'chapitre-4-toets',
        kind: 'open',
        prompt: 'Vertaal naar het Nederlands: tomber malade.',
        explanation: 'Tomber malade betekent ziek worden.',
        correctAnswer: 'ziek worden',
        difficulty: 2
      }),
      question({
        topic: 'chapitre-4-toets',
        prompt: 'Welke uitdrukking betekent "zijn best doen"?',
        explanation: 'Faire de son mieux betekent zijn best doen.',
        correctAnswer: 'faire de son mieux',
        difficulty: 2,
        options: ['faire de son mieux', 'avoir mal a', 'avoir lieu', 'rester']
      })
    ]
  },
  {
    moduleId: 1,
    summary: 'Rekenen met letters: haakjes, breuken, machten en wetenschappelijke notatie.',
    sections: [
      {
        heading: '1.1 Haakjes wegwerken',
        body: `Bij enkelvoudige haakjes vermenigvuldig je elke term binnen de haakjes met de factor ervoor: a(b + c) = ab + ac.

Bij dubbele haakjes vermenigvuldig je elke term uit de eerste haakjes met elke term uit de tweede haakjes. Voorbeeld: (x + 2)(x + 3) = x^2 + 5x + 6.`
      },
      {
        heading: '1.2 Breuken optellen en aftrekken',
        body: `Gelijknamige breuken kun je direct optellen of aftrekken. Niet-gelijknamige breuken maak je eerst gelijknamig.

Vereenvoudigen blijft belangrijk: deel teller en noemer door dezelfde factor of letter als dat mag. Bijvoorbeeld 28y / 4xy = 7 / x.`
      },
      {
        heading: '1.3 Breuken vermenigvuldigen en delen',
        body: `Bij vermenigvuldigen vermenigvuldig je teller met teller en noemer met noemer. Delen door een breuk betekent vermenigvuldigen met het omgekeerde.

Voorbeeld: 2/3 : 5/6 = 2/3 x 6/5 = 4/5.`
      },
      {
        heading: '1.4 Producten en gelijksoortige termen met machten',
        body: `Bij een product met hetzelfde grondtal tel je de exponenten op: a^p x a^q = a^(p+q).

Gelijksoortige termen mag je optellen of aftrekken als letters en exponenten gelijk zijn, bijvoorbeeld 6a^5 + 2a^5 = 8a^5.`
      },
      {
        heading: '1.5 Machten herleiden',
        body: `Belangrijke regels zijn: (a^p)^q = a^(p x q), (ab)^p = a^p x b^p en a^p / a^q = a^(p-q).

Let op het verschil tussen (−3a)^4 en −(3a)^4. In het eerste geval gaat het minteken mee in de macht, in het tweede niet.`
      },
      {
        heading: '1.6 Wetenschappelijke notatie',
        body: `Schrijf heel grote of kleine getallen als a x 10^n, waarbij 1 <= a < 10 en n een geheel getal is.

Verschuif de komma naar links voor een positief exponent en naar rechts voor een negatief exponent.`
      }
    ],
    questions: [
      question({
        topic: 'hoofdstuk-1-haakjes',
        prompt: 'Werk uit: 3a(2b - 6)',
        explanation: 'Vermenigvuldig 3a met beide termen: 6ab - 18a.',
        correctAnswer: '6ab - 18a',
        difficulty: 2,
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-haakjes',
        prompt: 'Wat is (x + 2)(x + 3)?',
        explanation: 'Je krijgt x^2 + 5x + 6.',
        correctAnswer: 'x^2 + 5x + 6',
        options: ['x^2 + 5x + 6', 'x^2 + x + 6', 'x^2 + 6x + 5', '2x^2 + 5x + 6']
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Vereenvoudig: 8x / 13x',
        explanation: 'Je deelt teller en noemer door x en houdt 8/13 over.',
        correctAnswer: '8/13',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Tel op: 2/a + 3/a',
        explanation: 'De breuken zijn gelijknamig, dus dat wordt 5/a.',
        correctAnswer: '5/a',
        options: ['5/a', '6/a', '5a', '1/a']
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Maak gelijknamig: 1/x + 4/y = ?',
        explanation: 'Je maakt noemer xy: (y + 4x)/(xy).',
        correctAnswer: '(y + 4x)/(xy)',
        difficulty: 3,
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Bereken: 2/3 : 5/6',
        explanation: 'Delen door een breuk is vermenigvuldigen met het omgekeerde: 4/5.',
        correctAnswer: '4/5',
        options: ['4/5', '5/4', '12/18', '2/5']
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Werk uit: a^2 x a^6',
        explanation: 'Bij gelijke grondtallen tel je de exponenten op: a^8.',
        correctAnswer: 'a^8',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Welke termen zijn gelijksoortig?',
        explanation: 'Alleen termen met dezelfde letters en dezelfde exponenten zijn gelijksoortig.',
        correctAnswer: '6a^5 en 2a^5',
        options: ['6a^5 en 2a^5', '6a^5 en 2a^3', '3xy en 5x', 'a^2 en a^3']
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Herleid: (a^3)^4',
        explanation: 'Bij een macht van een macht vermenigvuldig je de exponenten: a^12.',
        correctAnswer: 'a^12',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Herleid: a^8 / a^2',
        explanation: 'Bij deling van machten trek je de exponenten af: a^6.',
        correctAnswer: 'a^6',
        options: ['a^6', 'a^10', 'a^4', '1/a^6']
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Wat is (3a)^4?',
        explanation: 'Dat is 3^4 x a^4 = 81a^4.',
        correctAnswer: '81a^4',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-1-notatie',
        prompt: 'Schrijf 389000000000 in wetenschappelijke notatie.',
        explanation: 'Je verplaatst de komma 11 plaatsen: 3,89 x 10^11.',
        correctAnswer: '3,89 x 10^11',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-1-notatie',
        prompt: 'Welke schrijfwijze is correct?',
        explanation: 'In wetenschappelijke notatie moet het eerste getal tussen 1 en 10 liggen.',
        correctAnswer: '8,91 x 10^-9',
        options: ['89,1 x 10^-10', '0,891 x 10^-8', '8,91 x 10^-9', '891 x 10^-11']
      }),
      question({
        topic: 'hoofdstuk-1-haakjes',
        prompt: 'Werk uit: (a - 3)^2',
        explanation: 'Dat is (a - 3)(a - 3) = a^2 - 6a + 9.',
        correctAnswer: 'a^2 - 6a + 9',
        kind: 'open',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 2,
    summary: 'Oefenvragen bij hoofdstuk 1 over haakjes, breuken, machten en notatie.',
    sections: [],
    questions: [
      question({
        topic: 'hoofdstuk-1-haakjes',
        prompt: 'Werk uit: (a + 3)(b + 1)',
        explanation: 'Je krijgt ab + a + 3b + 3.',
        correctAnswer: 'ab + a + 3b + 3',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-haakjes',
        prompt: 'Wat is (a - 3)(a + 2)?',
        explanation: 'Dat wordt a^2 - a - 6.',
        correctAnswer: 'a^2 - a - 6',
        options: ['a^2 - a - 6', 'a^2 + a - 6', 'a^2 - 5a + 6', 'a^2 - 6']
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Vereenvoudig: 28y / 4xy',
        explanation: 'Deel door 4 en door y: 7/x.',
        correctAnswer: '7/x',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Bereken: 3/2b - 11/2b',
        explanation: 'Dat is -8/2b = -4/b.',
        correctAnswer: '-4/b',
        options: ['-4/b', '4/b', '-8/b', '8/2b']
      }),
      question({
        topic: 'hoofdstuk-1-breuken',
        prompt: 'Herleid: 3/ab x 6/b',
        explanation: 'Teller maal teller en noemer maal noemer geeft 18/abb, oftewel 18/(ab^2) als je het verder noteert.',
        correctAnswer: '18/(ab^2)',
        kind: 'open',
        difficulty: 4
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Herleid: 6x^3 x 4x^4',
        explanation: 'Je krijgt 24x^7.',
        correctAnswer: '24x^7',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Kan 6a^5 + 2a^3 worden samengenomen?',
        explanation: 'Nee, de exponenten verschillen.',
        correctAnswer: 'nee',
        options: ['ja', 'nee', 'alleen bij a = 1', 'alleen na delen door a']
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Herleid: (xy)^9',
        explanation: 'Een macht van een product wordt x^9y^9.',
        correctAnswer: 'x^9y^9',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-machten',
        prompt: 'Herleid: -(3a)^4',
        explanation: 'Dat is -81a^4.',
        correctAnswer: '-81a^4',
        options: ['81a^4', '-81a^4', '12a^4', '-12a^4']
      }),
      question({
        topic: 'hoofdstuk-1-notatie',
        prompt: 'Is 0,45 x 10^6 geldige wetenschappelijke notatie?',
        explanation: 'Nee, want het eerste getal moet tussen 1 en 10 liggen.',
        correctAnswer: 'nee',
        options: ['ja', 'nee', 'alleen bij kleine getallen', 'alleen als de exponent negatief is']
      })
    ]
  },
  {
    moduleId: 3,
    summary: 'Toetsvragen bij hoofdstuk 1 over haakjes, breuken, machten en notatie.',
    sections: [],
    questions: [
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Werk uit: -2(x - 3y)',
        explanation: 'Je vermenigvuldigt -2 met beide termen: -2x + 6y.',
        correctAnswer: '-2x + 6y',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Wat is 3/ab : 6/a?',
        explanation: 'Dit wordt 3/ab x a/6 = 1/(2b).',
        correctAnswer: '1/(2b)',
        difficulty: 4,
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Welke uitkomst hoort bij 6x^3 x 4x^4?',
        explanation: 'Je vermenigvuldigt de coëfficiënten en telt de exponenten op: 24x^7.',
        correctAnswer: '24x^7',
        options: ['10x^12', '24x^7', '24x^12', '10x^7']
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Herleid: 27a^12b^6 / 9a^9b',
        explanation: 'Je krijgt 3a^3b^5.',
        correctAnswer: '3a^3b^5',
        kind: 'open',
        difficulty: 4
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Welke uitspraak over wetenschappelijke notatie is juist?',
        explanation: 'Het eerste getal a moet tussen 1 en 10 liggen.',
        correctAnswer: 'Het eerste getal ligt tussen 1 en 10.',
        options: ['De exponent is altijd positief.', 'Het eerste getal ligt tussen 1 en 10.', 'Je gebruikt nooit decimalen.', 'Kleine getallen krijgen een positieve exponent.']
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Tel op: 2a/5 + (a - 3)/3',
        explanation: 'Gelijknamig maken geeft (11a - 15)/15.',
        correctAnswer: '(11a - 15)/15',
        kind: 'open',
        difficulty: 4
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Welke herleiding is goed?',
        explanation: '6a^5 + 2a^3 zijn niet gelijksoortig en kun je dus niet samenvoegen.',
        correctAnswer: '6a^5 + 2a^3 is niet te herleiden',
        options: ['6a^8', '8a^5', '8a^3', '6a^5 + 2a^3 is niet te herleiden']
      }),
      question({
        topic: 'hoofdstuk-1-toets',
        prompt: 'Schrijf 0,000000000891 in wetenschappelijke notatie.',
        explanation: 'Dit is 8,91 x 10^-10 als je tien plaatsen telt vanaf 8,91? Nee, volgens de samenvatting is het 8,91 x 10^-10 voor dit exacte getal met negen nullen na de komma voor 891. ',
        correctAnswer: '8,91 x 10^-10',
        kind: 'open',
        difficulty: 4
      })
    ]
  },
  {
    moduleId: 4,
    summary: 'Lineaire formules en vergelijkingen: grafieken, formules opstellen en balansmethode.',
    sections: [
      {
        heading: '3.1 Grafieken van lineaire formules',
        body: `Een lineaire formule heeft de vorm y = ax + b. De grafiek is een rechte lijn.

Om een lijn te tekenen, kies je minstens twee x-waarden en reken je de bijbehorende y-waarden uit. Je kunt ook controleren of een punt op de lijn ligt door de x-waarde in te vullen en te kijken of de y-waarde klopt.`
      },
      {
        heading: '3.2 De formule van een lijn opstellen',
        body: `Elke rechte lijn heeft een formule van de vorm y = ax + b. De richtingscoefficient a geeft aan hoeveel de lijn stijgt of daalt als x 1 groter wordt.

De constante b is het snijpunt met de y-as. Evenwijdige lijnen hebben dezelfde a.`
      },
      {
        heading: '3.3 De balansmethode',
        body: `Bij een vergelijking doe je aan beide kanten steeds dezelfde bewerking. Zo blijft de vergelijking in balans.

Werk stap voor stap: maak eerst x-term of getallen vrij, en deel daarna door de coefficient van x.`
      },
      {
        heading: '3.4 Vergelijkingen oplossen en snijpunten vinden',
        body: `Bij vergelijkingen met x aan beide kanten breng je eerst de x-termen naar een kant en de gewone getallen naar de andere.

Bij haakjes werk je eerst de haakjes weg. Bij breuken vermenigvuldig je vaak eerst met de noemer of met het kleinste gemene veelvoud. Een snijpunt van twee lijnen vind je door de formules aan elkaar gelijk te stellen.`
      }
    ],
    questions: [
      question({
        topic: 'hoofdstuk-3-grafieken',
        prompt: 'Welke vorm heeft een lineaire formule?',
        explanation: 'Een lineaire formule heeft de vorm y = ax + b.',
        correctAnswer: 'y = ax + b',
        options: ['y = ax + b', 'y = ax^2 + b', 'y = a/x + b', 'y = a + b/x']
      }),
      question({
        topic: 'hoofdstuk-3-grafieken',
        prompt: 'Bereken y als x = 4 in y = -1/2x + 3.',
        explanation: 'y = -1/2 x 4 + 3 = -2 + 3 = 1.',
        correctAnswer: '1',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-grafieken',
        prompt: 'Ligt A(20, -7) op y = -1/2x + 3?',
        explanation: 'Invullen geeft -1/2 x 20 + 3 = -7, dus ja.',
        correctAnswer: 'ja',
        options: ['ja', 'nee', 'alleen als x = -20', 'niet te bepalen']
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Wat betekent de richtingscoefficient a?',
        explanation: 'A geeft aan hoeveel de lijn omhoog of omlaag gaat als x 1 toeneemt.',
        correctAnswer: 'de stijging of daling per stap naar rechts',
        options: ['het snijpunt met de x-as', 'de stijging of daling per stap naar rechts', 'de beginwaarde van x', 'de uitkomst bij x = 1']
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Welke b hoort bij het punt (0, 4)?',
        explanation: 'Het punt met x = 0 geeft direct het snijpunt met de y-as, dus b = 4.',
        correctAnswer: '4',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Bereken a voor een lijn door (0, 4) en (2, 1).',
        explanation: 'a = (1 - 4) / (2 - 0) = -3/2.',
        correctAnswer: '-3/2',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-3-balansmethode',
        prompt: 'Los op: 5x - 3 = 37',
        explanation: 'Tel 3 op en deel daarna door 5: x = 8.',
        correctAnswer: '8',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-balansmethode',
        prompt: 'Welke stap hoort bij de balansmethode?',
        explanation: 'Je moet aan beide kanten dezelfde bewerking uitvoeren.',
        correctAnswer: 'je doet aan beide kanten hetzelfde',
        options: ['je rekent alleen links', 'je doet aan beide kanten hetzelfde', 'je deelt alleen als er geen x staat', 'je werkt altijd eerst naar rechts']
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Los op: 6x - 15 = 8x - 7',
        explanation: 'Breng x-termen en getallen samen: -2x = 8, dus x = -4.',
        correctAnswer: '-4',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Wat doe je eerst bij 3(2x - 6) + 3 = 8x - 7?',
        explanation: 'Eerst werk je de haakjes weg.',
        correctAnswer: 'de haakjes wegwerken',
        options: ['delen door 3', 'de haakjes wegwerken', 'x naar rechts brengen', 'het rechterlid vereenvoudigen']
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Wat is het snijpunt van y = 3x - 3 en y = -x + 5?',
        explanation: 'Gelijkstellen geeft x = 2 en daarna y = 3, dus S(2, 3).',
        correctAnswer: 'S(2, 3)',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Wat is een handige eerste stap bij een vergelijking met breuken?',
        explanation: 'Vermenigvuldig beide leden met de noemer of het kgv van de noemers.',
        correctAnswer: 'vermenigvuldig beide leden met de noemer of het kgv',
        options: ['maak eerst een tabel', 'vermenigvuldig beide leden met de noemer of het kgv', 'deel meteen door x', 'werk eerst de uitkomst uit']
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Los op: 10x - 6 = 3x + 1',
        explanation: '7x = 7, dus x = 1.',
        correctAnswer: '1',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Hoe weet je dat twee lijnen evenwijdig zijn?',
        explanation: 'Evenwijdige lijnen hebben dezelfde richtingscoefficient a.',
        correctAnswer: 'ze hebben dezelfde richtingscoefficient',
        options: ['ze hebben hetzelfde snijpunt met de y-as', 'ze hebben dezelfde richtingscoefficient', 'ze gaan allebei door de oorsprong', 'ze dalen allebei']
      })
    ]
  },
  {
    moduleId: 5,
    summary: 'Oefenvragen bij hoofdstuk 3 over lineaire formules, balansmethode en vergelijkingen.',
    sections: [],
    questions: [
      question({
        topic: 'hoofdstuk-3-grafieken',
        prompt: 'Welke grafiek hoort bij een lineaire formule?',
        explanation: 'Een lineaire formule geeft een rechte lijn.',
        correctAnswer: 'een rechte lijn',
        options: ['een rechte lijn', 'een cirkel', 'een parabool', 'een staafdiagram']
      }),
      question({
        topic: 'hoofdstuk-3-grafieken',
        prompt: 'Wat is y bij x = 0 in y = -1/2x + 3?',
        explanation: 'Invullen geeft y = 3.',
        correctAnswer: '3',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Wat is b in y = -1,5x + 4?',
        explanation: 'B is het snijpunt met de y-as, dus 4.',
        correctAnswer: '4',
        options: ['-1,5', '4', '1,5', '0']
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Wat is a voor B = -8t + 300?',
        explanation: 'De richtingscoefficient is -8.',
        correctAnswer: '-8',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-balansmethode',
        prompt: 'Welke bewerking doe je eerst bij 5x - 3 = 37?',
        explanation: 'Eerst tel je 3 op bij beide kanten.',
        correctAnswer: '+3 aan beide kanten',
        options: ['delen door 5', '+3 aan beide kanten', '-37 aan beide kanten', 'x naar rechts brengen']
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Los op: -2x = 8',
        explanation: 'Deel beide kanten door -2: x = -4.',
        correctAnswer: '-4',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Wat doe je bij vergelijkingen met haakjes?',
        explanation: 'Eerst werk je de haakjes weg.',
        correctAnswer: 'eerst de haakjes wegwerken',
        options: ['eerst de haakjes wegwerken', 'eerst door x delen', 'eerst het rechterlid wegstrepen', 'eerst een grafiek tekenen']
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Wat is x in 4x = 8?',
        explanation: 'x = 2.',
        correctAnswer: '2',
        kind: 'open'
      }),
      question({
        topic: 'hoofdstuk-3-vergelijkingen',
        prompt: 'Waarom gebruik je bij breuken vaak het kgv?',
        explanation: 'Zo kun je alle noemers tegelijk wegwerken.',
        correctAnswer: 'om alle noemers tegelijk weg te werken',
        options: ['om de richtingscoefficient te vinden', 'om alle noemers tegelijk weg te werken', 'om b te bepalen', 'om een tabel te maken']
      }),
      question({
        topic: 'hoofdstuk-3-formules',
        prompt: 'Wanneer zijn twee lijnen evenwijdig?',
        explanation: 'Als ze dezelfde richtingscoefficient hebben.',
        correctAnswer: 'als a gelijk is',
        kind: 'open'
      })
    ]
  },
  {
    moduleId: 6,
    summary: 'Toetsvragen bij hoofdstuk 3 over lineaire formules en vergelijkingen.',
    sections: [],
    questions: [
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Stel de formule op van de lijn door (0, 4) en (2, 1).',
        explanation: 'a = -3/2 en b = 4, dus y = -3/2x + 4.',
        correctAnswer: 'y = -3/2x + 4',
        kind: 'open',
        difficulty: 4
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Los op met de balansmethode: 3x - 36 = 54',
        explanation: 'Tel 36 op en deel door 3: x = 30.',
        correctAnswer: '30',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Welke uitspraak is juist?',
        explanation: 'b is het snijpunt met de y-as.',
        correctAnswer: 'b is het snijpunt met de y-as',
        options: ['a is altijd positief', 'b is het snijpunt met de y-as', 'een lineaire grafiek is een parabool', 'een lijn heeft nooit een negatieve a']
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Los op: 3(2x - 6) + 3 = 8x - 7',
        explanation: 'Na wegwerken van haakjes krijg je 6x - 15 = 8x - 7, dus x = -4.',
        correctAnswer: '-4',
        kind: 'open',
        difficulty: 4
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Welk punt ligt op y = 2x + 1?',
        explanation: 'Voor x = 3 krijg je y = 7, dus (3, 7) ligt op de lijn.',
        correctAnswer: '(3, 7)',
        options: ['(3, 6)', '(3, 7)', '(2, 1)', '(0, 2)']
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Wat is de eerste stap bij 1 3/7 x = 20 als vergelijking?',
        explanation: 'Je vermenigvuldigt beide kanten eerst met 7 om de breuk weg te werken.',
        correctAnswer: 'beide kanten met 7 vermenigvuldigen',
        options: ['delen door 20', 'beide kanten met 7 vermenigvuldigen', 'x naar rechts brengen', 'het antwoord gokken']
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Vind x uit 3x - 3 = -x + 5.',
        explanation: '4x = 8, dus x = 2.',
        correctAnswer: '2',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: 'hoofdstuk-3-toets',
        prompt: 'Wanneer daalt een lineaire grafiek?',
        explanation: 'Een lijn daalt bij een negatieve richtingscoefficient.',
        correctAnswer: 'als a negatief is',
        options: ['als b negatief is', 'als a negatief is', 'als x toeneemt', 'als de lijn door de oorsprong gaat']
      })
    ]
  },
  {
    moduleId: 35,
    summary: 'Liefde voor het vaderland: Congres van Wenen, restauratie en nationalisme.',
    sections: [
      {
        heading: 'Congres van Wenen en restauratie',
        body: `Na de tijd van Napoleon wilden Europese leiders rust en orde herstellen. Op het Congres van Wenen in 1814-1815 spraken zij af om zoveel mogelijk terug te keren naar de situatie van voor de Franse Revolutie.

Dat herstel heet restauratie. In veel landen kwam opnieuw een vorst aan het hoofd te staan.`
      },
      {
        heading: 'Wat is nationalisme?',
        body: `Nationalisme is grote liefde voor het eigen land, volk en cultuur. Het kan cultureel zijn, bijvoorbeeld trots op taal en tradities, maar ook politiek-bestuurlijk, als mensen willen dat een volk een eigen staat heeft.

Nationalisme kon mensen verbinden, maar zorgde ook voor spanningen tussen volkeren.`
      },
      {
        heading: 'Gevolgen voor Nederland en Europa',
        body: `In de negentiende eeuw leidde nationalisme onder andere tot de Belgische Opstand van 1830 en later tot de vorming van nieuwe eenheidsstaten zoals Duitsland.

Door nationalisme groeide ook de bereidheid om voor het vaderland te vechten. Dat sluit aan bij militarisme: het idee dat oorlog een goede manier is om conflicten op te lossen.`
      }
    ],
    questions: [
      question({
        topic: '5-1-restauratie',
        prompt: 'Wat werd op het Congres van Wenen nagestreefd?',
        explanation: 'Men wilde de oude orde herstellen en rust in Europa terugbrengen.',
        correctAnswer: 'herstel van de oude orde in Europa',
        options: ['afschaffing van koningen', 'herstel van de oude orde in Europa', 'het verdelen van Afrika', 'het invoeren van democratie overal']
      }),
      question({
        topic: '5-1-restauratie',
        prompt: 'Wat betekent restauratie?',
        explanation: 'Restauratie is herstel van de situatie van voor de Franse Revolutie.',
        correctAnswer: 'herstel van de oude politiek-bestuurlijke situatie',
        options: ['verdeling van kolonieen', 'herstel van de oude politiek-bestuurlijke situatie', 'industrialisatie', 'vrije verkiezingen']
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Wat is nationalisme?',
        explanation: 'Nationalisme is grote liefde voor het eigen land, volk en cultuur.',
        correctAnswer: 'grote liefde voor eigen land, volk en cultuur',
        options: ['geloof in wereldhandel', 'grote liefde voor eigen land, volk en cultuur', 'macht van fabrieken', 'besturen via plaatselijke vorsten']
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Welke gebeurtenis uit 1830 past bij nationalistische spanningen?',
        explanation: 'De Belgische Opstand van 1830 hing samen met nationalistische gevoelens.',
        correctAnswer: 'de Belgische Opstand',
        options: ['de Conferentie van Berlijn', 'de Belgische Opstand', 'de val van de VOC', 'de aanleg van spoorwegen']
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Wat is militarisme?',
        explanation: 'Militarisme is het idee dat oorlog een goede manier is om conflicten op te lossen.',
        correctAnswer: 'het idee dat oorlog conflicten kan oplossen',
        options: ['vreedzaam overleg tussen landen', 'het idee dat oorlog conflicten kan oplossen', 'liefde voor kunst en cultuur', 'bestuur zonder leger']
      }),
      question({
        topic: '5-1-nationalisme',
        kind: 'open',
        prompt: 'Noem een gevolg van nationalisme in Europa in de 19e eeuw.',
        explanation: 'Mogelijke antwoorden zijn de Belgische Opstand, de vorming van Duitsland of meer steun voor oorlog en leger.',
        correctAnswer: 'de Belgische Opstand',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 36,
    summary: 'Oefenvragen bij paragraaf 5.1 over restauratie en nationalisme.',
    sections: [],
    questions: [
      question({
        topic: '5-1-restauratie',
        prompt: 'Welk begrip past bij herstel van vorsten na Napoleon?',
        explanation: 'Dat heet restauratie.',
        correctAnswer: 'restauratie',
        options: ['nationalisme', 'restauratie', 'imperialisme', 'racisme']
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Noem een cultureel voorbeeld van nationalisme.',
        explanation: 'Trots op de eigen taal of cultuur is een cultureel voorbeeld.',
        correctAnswer: 'trots op de eigen taal',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Welke gebeurtenis hoort bij 1830?',
        explanation: 'Dat is de Belgische Opstand.',
        correctAnswer: 'de Belgische Opstand',
        options: ['de Belgische Opstand', 'de Conferentie van Berlijn', 'de val van de VOC', 'het ontstaan van het Duitse Keizerrijk']
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Waarom kon nationalisme mensen verbinden?',
        explanation: 'Omdat mensen zich onderdeel voelden van hetzelfde volk of dezelfde cultuur.',
        correctAnswer: 'omdat mensen zich onderdeel voelden van hetzelfde volk',
        options: ['omdat iedereen hetzelfde beroep had', 'omdat mensen zich onderdeel voelden van hetzelfde volk', 'omdat oorlog verboden werd', 'omdat kolonieen verdwenen']
      }),
      question({
        topic: '5-1-nationalisme',
        prompt: 'Wat hoort het best bij militarisme?',
        explanation: 'Militarisme legt veel nadruk op leger, wapens en discipline.',
        correctAnswer: 'veel nadruk op leger en wapens',
        options: ['veel nadruk op leger en wapens', 'volledige afkeer van oorlog', 'alleen economische groei', 'bestuur via vorsten in kolonieen']
      }),
      question({
        topic: '5-1-restauratie',
        prompt: 'Waarom wilden leiders in 1815 vooral rust en orde?',
        explanation: 'Ze wilden de onrust van de Franse Revolutie en Napoleon stoppen.',
        correctAnswer: 'om de revolutionaire onrust te stoppen',
        options: ['om de industrialisatie te versnellen', 'om de revolutionaire onrust te stoppen', 'om Afrika te verdelen', 'om alle vorsten af te zetten']
      })
    ]
  },
  {
    moduleId: 37,
    summary: 'Toets bij paragraaf 5.1 over restauratie, nationalisme en militarisme.',
    sections: [],
    questions: [
      question({
        topic: '5-1-toets',
        prompt: 'In welk jaar vond het Congres van Wenen plaats?',
        explanation: 'Het Congres van Wenen vond plaats in 1814-1815.',
        correctAnswer: '1814-1815',
        kind: 'open',
        difficulty: 3
      }),
      question({
        topic: '5-1-toets',
        prompt: 'Welke combinatie klopt?',
        explanation: 'Restauratie hoort bij herstel van de oude orde.',
        correctAnswer: 'restauratie - herstel van de oude orde',
        options: ['restauratie - industrialisatie', 'restauratie - herstel van de oude orde', 'nationalisme - bestuur via inheemse vorsten', 'militarisme - vrije handel']
      }),
      question({
        topic: '5-1-toets',
        prompt: 'Waarom kon nationalisme ook tot conflict leiden?',
        explanation: 'Verschillende volkeren konden botsen over grondgebied, macht en een eigen staat.',
        correctAnswer: 'omdat volkeren konden botsen over een eigen staat en macht',
        options: ['omdat iedereen dezelfde taal sprak', 'omdat volkeren konden botsen over een eigen staat en macht', 'omdat er geen legers meer waren', 'omdat alle landen een kolonie hadden']
      }),
      question({
        topic: '5-1-toets',
        kind: 'open',
        prompt: 'Leg kort uit wat militarisme betekent.',
        explanation: 'Militarisme is het idee dat oorlog en een sterk leger goede middelen zijn om problemen op te lossen.',
        correctAnswer: 'het idee dat oorlog en een sterk leger goede middelen zijn',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 38,
    summary: 'Europa gaat de wereld overheersen: modern imperialisme en bestuur in Brits-Indie.',
    sections: [
      {
        heading: 'Van handelscontacten naar wereldrijken',
        body: `Europese handelscontacten groeiden in de negentiende eeuw uit tot grote wereldrijken. Europese landen wilden niet alleen handel drijven, maar ook gebieden besturen en economisch gebruiken.

Zo ontstonden imperia met kolonieen overzee.`
      },
      {
        heading: 'Modern imperialisme',
        body: `Modern imperialisme is het streven van Europese landen in de negentiende eeuw naar een groot overzees rijk. Kolonieen leverden grondstoffen en vormden afzetgebieden voor Europese producten.

Oorzaken waren onder andere industrialisatie, machtspolitiek, nationalisme en superioriteitsdenken.`
      },
      {
        heading: 'Brits-Indie en indirect bestuur',
        body: `In Brits-Indie bestuurden Europeanen grote gebieden vaak indirect. Dat betekent dat zij regeerden via plaatselijke vorsten.

Zo hield Groot-Brittannie controle, terwijl bestaande machtsstructuren deels bleven bestaan.`
      }
    ],
    questions: [
      question({
        topic: '5-2-imperialisme',
        prompt: 'Wat is een imperium?',
        explanation: 'Een imperium is een groot rijk, vaak met gebieden overzee.',
        correctAnswer: 'een groot rijk',
        options: ['een klein stadsbestuur', 'een groot rijk', 'een fabriek', 'een politiek verdrag']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Wat betekent modern imperialisme?',
        explanation: 'Dat is het streven naar een groot overzees rijk in de 19e eeuw.',
        correctAnswer: 'het streven naar een groot overzees rijk',
        options: ['het opheffen van kolonieen', 'het streven naar een groot overzees rijk', 'liefde voor kunst en wetenschap', 'de invoering van democratie']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Waarom waren kolonieen economisch aantrekkelijk?',
        explanation: 'Ze leverden grondstoffen en waren afzetgebieden voor producten.',
        correctAnswer: 'door grondstoffen en afzetgebieden',
        options: ['door gratis verkiezingen', 'door grondstoffen en afzetgebieden', 'door het gebrek aan bevolking', 'door restauratie']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Wat is superioriteitsdenken?',
        explanation: 'Dat is het gevoel dat de eigen beschaving meer waard is dan die van anderen.',
        correctAnswer: 'denken dat je eigen beschaving beter is',
        options: ['denken dat alle culturen gelijk zijn', 'denken dat je eigen beschaving beter is', 'trots op je stad', 'het steunen van arbeiders']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Wat is indirect bestuur?',
        explanation: 'Indirect bestuur betekent regeren via inheemse vorsten.',
        correctAnswer: 'besturen via inheemse vorsten',
        options: ['besturen zonder wetten', 'besturen via inheemse vorsten', 'besturen vanuit een parlement in de kolonie', 'volledig zelfbestuur']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Welke houding sloot vaak aan bij modern imperialisme?',
        explanation: 'Racisme en superioriteitsdenken werden vaak gebruikt om imperialisme te rechtvaardigen.',
        correctAnswer: 'racisme',
        options: ['pacifisme', 'racisme', 'sociale zekerheid', 'neutraliteit']
      })
    ]
  },
  {
    moduleId: 39,
    summary: 'Oefenvragen bij paragraaf 5.2 over modern imperialisme.',
    sections: [],
    questions: [
      question({
        topic: '5-2-imperialisme',
        prompt: 'Wat zochten Europese landen vaak in kolonieen?',
        explanation: 'Ze zochten grondstoffen en afzetgebieden.',
        correctAnswer: 'grondstoffen en afzetgebieden',
        options: ['alleen religieuze vrijheid', 'grondstoffen en afzetgebieden', 'vrije verkiezingen', 'kleine dorpen']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Welke ontwikkeling maakte meer grondstoffen nodig?',
        explanation: 'De industrialisatie zorgde voor meer vraag naar grondstoffen.',
        correctAnswer: 'industrialisatie',
        options: ['restauratie', 'industrialisatie', 'de Belgische Opstand', 'feodalisme']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Wat betekent racisme in deze context?',
        explanation: 'Dat is het onjuiste idee dat sommige rassen superieur zijn aan andere.',
        correctAnswer: 'het idee dat sommige rassen superieur zijn',
        options: ['liefde voor het vaderland', 'het idee dat sommige rassen superieur zijn', 'bestuur via plaatselijke vorsten', 'de verkoop van producten']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Waarom paste superioriteitsdenken bij imperialisme?',
        explanation: 'Het werd gebruikt om overheersing van andere volken te rechtvaardigen.',
        correctAnswer: 'om overheersing te rechtvaardigen',
        options: ['om onafhankelijkheid te geven', 'om overheersing te rechtvaardigen', 'om oorlog te voorkomen', 'om de VOC te redden']
      }),
      question({
        topic: '5-2-imperialisme',
        prompt: 'Welke bestuursvorm zie je bij regeren via lokale vorsten?',
        explanation: 'Dat noem je indirect bestuur.',
        correctAnswer: 'indirect bestuur',
        options: ['directe democratie', 'indirect bestuur', 'federalisme', 'restauratie']
      }),
      question({
        topic: '5-2-imperialisme',
        kind: 'open',
        prompt: 'Noem een economisch doel van een kolonie.',
        explanation: 'Een kolonie leverde bijvoorbeeld grondstoffen of vormde een afzetgebied.',
        correctAnswer: 'grondstoffen leveren',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 40,
    summary: 'Toets bij paragraaf 5.2 over imperialisme en Brits-Indie.',
    sections: [],
    questions: [
      question({
        topic: '5-2-toets',
        prompt: 'Wat is een afzetgebied?',
        explanation: 'Een afzetgebied is een gebied waar je producten kunt verkopen.',
        correctAnswer: 'een gebied waar je producten kunt verkopen',
        options: ['een gebied met alleen grondstoffen', 'een gebied waar je producten kunt verkopen', 'een militair oefenterrein', 'een bestuur zonder vorst']
      }),
      question({
        topic: '5-2-toets',
        kind: 'open',
        prompt: 'Noem twee oorzaken van het modern imperialisme.',
        explanation: 'Goede voorbeelden zijn industrialisatie, nationalisme, machtspolitiek en superioriteitsdenken.',
        correctAnswer: 'industrialisatie en nationalisme',
        difficulty: 3
      }),
      question({
        topic: '5-2-toets',
        prompt: 'Waarom past indirect bestuur bij Brits-Indie?',
        explanation: 'Groot-Brittannie kon zo via lokale vorsten toch de macht houden.',
        correctAnswer: 'om via lokale vorsten de macht te behouden',
        options: ['om alle Europeanen te laten vertrekken', 'om via lokale vorsten de macht te behouden', 'om verkiezingen in te voeren', 'om industrie te stoppen']
      }),
      question({
        topic: '5-2-toets',
        prompt: 'Welke begrippen horen inhoudelijk bij elkaar?',
        explanation: 'Modern imperialisme hing samen met grondstoffen en afzetgebieden.',
        correctAnswer: 'modern imperialisme - grondstoffen en afzetgebieden',
        options: ['modern imperialisme - grondstoffen en afzetgebieden', 'restauratie - Conferentie van Berlijn', 'nationalisme - bestuur via inheemse vorsten', 'racisme - herstel van vorsten']
      })
    ]
  },
  {
    moduleId: 41,
    summary: 'Nederlands-Indie: ontstaan van de kolonie, bestuur en economie.',
    sections: [
      {
        heading: 'Ontstaan van Nederlands-Indie',
        body: `Toen de VOC in 1799 failliet ging, nam de Nederlandse staat de bezittingen over. Zo ontstond Nederlands-Indie als Nederlandse kolonie in Zuidoost-Azie.

De hoogste bestuurder was de gouverneur-generaal.`
      },
      {
        heading: 'Bestuur van de kolonie',
        body: `Nederland bestuurde Nederlands-Indie met een combinatie van Europese bestuurders en lokale machthebbers. Daarmee hield Nederland grip op het gebied.

De koloniale overheid bepaalde uiteindelijk de regels en het economische beleid.`
      },
      {
        heading: 'Economie en samenleving',
        body: `In 1830 werd het cultuurstelsel ingevoerd. Boeren moesten een deel van hun grond gebruiken voor producten die Nederland kon verkopen, zoals koffie of suiker.

Dat leverde Nederland veel geld op, maar voor veel inwoners van Nederlands-Indie betekende het zware lasten en minder ruimte voor eigen voedselproductie.`
      }
    ],
    questions: [
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wat gebeurde er in 1799?',
        explanation: 'In 1799 ging de VOC failliet en ontstond de basis voor Nederlands-Indie.',
        correctAnswer: 'de VOC ging failliet',
        options: ['de VOC ging failliet', 'de Conferentie van Berlijn begon', 'de Belgische Opstand startte', 'Duitsland werd een keizerrijk']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wat was Nederlands-Indie?',
        explanation: 'Dat was de Nederlandse kolonie in Zuidoost-Azie.',
        correctAnswer: 'de Nederlandse kolonie in Zuidoost-Azie',
        options: ['een Britse kolonie in Afrika', 'de Nederlandse kolonie in Zuidoost-Azie', 'een stad in Nederland', 'een handelsbedrijf']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wie was de hoogste bestuurder van Nederlands-Indie?',
        explanation: 'Dat was de gouverneur-generaal.',
        correctAnswer: 'de gouverneur-generaal',
        options: ['de koning van Java', 'de gouverneur-generaal', 'de VOC-directeur', 'de conferentievoorzitter']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wat hield het cultuurstelsel in?',
        explanation: 'Boeren moesten een deel van hun grond gebruiken voor exportgewassen.',
        correctAnswer: 'boeren moesten grond gebruiken voor exportgewassen',
        options: ['boeren kregen volledige vrijheid', 'boeren moesten grond gebruiken voor exportgewassen', 'Nederland trok zich terug uit de kolonie', 'alle handel werd verboden']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wat was een gevolg van het cultuurstelsel voor Nederland?',
        explanation: 'Het leverde de Nederlandse staat veel geld op.',
        correctAnswer: 'Nederland verdiende er veel geld mee',
        options: ['Nederland verloor alle handel', 'Nederland verdiende er veel geld mee', 'Nederland moest herstelbetalingen doen', 'Nederland kreeg minder macht']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Waarom was het cultuurstelsel zwaar voor de bevolking?',
        explanation: 'Er bleef minder grond en tijd over voor voedsel en eigen inkomsten.',
        correctAnswer: 'er bleef minder ruimte over voor eigen voedselproductie',
        options: ['er waren te veel verkiezingen', 'er bleef minder ruimte over voor eigen voedselproductie', 'de kolonie werd onafhankelijk', 'er kwamen geen belastingen meer']
      })
    ]
  },
  {
    moduleId: 42,
    summary: 'Oefenvragen bij paragraaf 5.3 over Nederlands-Indie.',
    sections: [],
    questions: [
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wat nam de Nederlandse staat over na het failliet van de VOC?',
        explanation: 'De staat nam de bezittingen van de VOC over.',
        correctAnswer: 'de bezittingen van de VOC',
        options: ['de Belgische troon', 'de bezittingen van de VOC', 'Afrikaanse kolonieen', 'Brits-Indie']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'In welk gebied lag Nederlands-Indie?',
        explanation: 'In Zuidoost-Azie, het huidige Indonesie.',
        correctAnswer: 'Zuidoost-Azie',
        options: ['West-Afrika', 'Zuidoost-Azie', 'Zuid-Amerika', 'Oost-Europa']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Wat was de taak van de gouverneur-generaal?',
        explanation: 'Hij stond aan het hoofd van het koloniale bestuur.',
        correctAnswer: 'leiding geven aan het koloniale bestuur',
        options: ['leiding geven aan het koloniale bestuur', 'de VOC failliet verklaren', 'de bevolking kiezen laten houden', 'de Conferentie van Berlijn organiseren']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Welke producten werden via het cultuurstelsel belangrijk voor export?',
        explanation: 'Bijvoorbeeld koffie en suiker.',
        correctAnswer: 'koffie en suiker',
        options: ['aardappelen en wol', 'koffie en suiker', 'ijzer en kolen', 'vis en graan']
      }),
      question({
        topic: '5-3-nederlands-indie',
        prompt: 'Waarom was de economie in de kolonie vooral op Nederland gericht?',
        explanation: 'Omdat het koloniale systeem vooral Nederlandse belangen diende.',
        correctAnswer: 'om Nederlandse belangen te dienen',
        options: ['om lokale democratie te versterken', 'om Nederlandse belangen te dienen', 'om handel te verbieden', 'om oorlog te voorkomen']
      }),
      question({
        topic: '5-3-nederlands-indie',
        kind: 'open',
        prompt: 'Noem een nadeel van het cultuurstelsel voor de bevolking.',
        explanation: 'Een nadeel was minder ruimte voor voedselproductie of meer dwangarbeid en belastingdruk.',
        correctAnswer: 'minder ruimte voor voedselproductie',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 43,
    summary: 'Toets bij paragraaf 5.3 over Nederlands-Indie en het cultuurstelsel.',
    sections: [],
    questions: [
      question({
        topic: '5-3-toets',
        prompt: 'Wat is de juiste volgorde?',
        explanation: 'Eerst ging de VOC failliet, daarna ontstond Nederlands-Indie en later kwam het cultuurstelsel.',
        correctAnswer: 'VOC failliet - Nederlands-Indie - cultuurstelsel',
        options: ['cultuurstelsel - VOC failliet - Nederlands-Indie', 'VOC failliet - Nederlands-Indie - cultuurstelsel', 'Nederlands-Indie - Conferentie van Berlijn - cultuurstelsel', 'Belgische Opstand - VOC failliet - cultuurstelsel']
      }),
      question({
        topic: '5-3-toets',
        kind: 'open',
        prompt: 'Leg kort uit waarom het cultuurstelsel gunstig was voor Nederland.',
        explanation: 'Nederland kreeg veel inkomsten uit de verkoop van exportgewassen.',
        correctAnswer: 'Nederland kreeg veel inkomsten uit exportgewassen',
        difficulty: 3
      }),
      question({
        topic: '5-3-toets',
        prompt: 'Welke functie hoort bij bestuur van de kolonie?',
        explanation: 'De gouverneur-generaal stond aan het hoofd van het koloniale bestuur.',
        correctAnswer: 'gouverneur-generaal',
        options: ['president van Indie', 'gouverneur-generaal', 'burgemeester van Batavia', 'minister-president van Java']
      }),
      question({
        topic: '5-3-toets',
        prompt: 'Welke omschrijving past het best bij Nederlands-Indie?',
        explanation: 'Het was een Nederlandse kolonie in Zuidoost-Azie.',
        correctAnswer: 'een Nederlandse kolonie in Zuidoost-Azie',
        options: ['een Nederlandse kolonie in Zuidoost-Azie', 'een onafhankelijk Aziatisch rijk', 'een Britse fabriekzone', 'een Europees bondgenootschap']
      })
    ]
  },
  {
    moduleId: 44,
    summary: 'De wedloop om Afrika: verdeling, Conferentie van Berlijn en gevolgen.',
    sections: [
      {
        heading: 'Afrika rond 1800',
        body: `Afrika bestond rond 1800 uit veel verschillende samenlevingen en rijken. Europese invloed was vooral aanwezig aan de kust.

Later trokken Europeanen verder het binnenland in, op zoek naar handel, grondstoffen en macht.`
      },
      {
        heading: 'De wedloop om Afrika',
        body: `In de tweede helft van de negentiende eeuw probeerden Europese landen zo snel mogelijk delen van Afrika te veroveren. Dat heet de wedloop om Afrika.

Nationalisme speelde mee: landen wilden laten zien hoe machtig zij waren.`
      },
      {
        heading: 'Conferentie van Berlijn en gevolgen',
        body: `Op de Conferentie van Berlijn in 1884-1885 verdeelden Europese landen grote delen van Afrika onder elkaar, zonder Afrikaanse bevolking mee te laten beslissen.

Dat leidde tot kunstmatige grenzen, geweld en langdurige politieke problemen.`
      }
    ],
    questions: [
      question({
        topic: '5-4-afrika',
        prompt: 'Hoe zag Afrika er rond 1800 uit?',
        explanation: 'Er waren veel verschillende samenlevingen en rijken; Europa beheerste nog niet het hele continent.',
        correctAnswer: 'het bestond uit veel verschillende samenlevingen en rijken',
        options: ['het was al helemaal Europees', 'het bestond uit veel verschillende samenlevingen en rijken', 'er woonden bijna geen mensen', 'het was een eenheidsstaat']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Wat wordt bedoeld met de wedloop om Afrika?',
        explanation: 'Europese landen probeerden snel delen van Afrika te veroveren.',
        correctAnswer: 'de snelle verovering en verdeling van Afrika door Europese landen',
        options: ['de snelle verovering en verdeling van Afrika door Europese landen', 'de industrialisatie van Afrika', 'de strijd tussen Afrikaanse staten onderling', 'de terugtrekking van Europa uit Afrika']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Waarom speelde nationalisme een rol bij de kolonisatie van Afrika?',
        explanation: 'Landen wilden door kolonieen hun macht en prestige tonen.',
        correctAnswer: 'landen wilden hun macht en prestige tonen',
        options: ['landen wilden vrede sluiten', 'landen wilden hun macht en prestige tonen', 'landen wilden minder gebied hebben', 'landen wilden de slavernij invoeren']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Wat gebeurde er op de Conferentie van Berlijn?',
        explanation: 'Europese landen verdeelden grote delen van Afrika onder elkaar.',
        correctAnswer: 'Europese landen verdeelden Afrika onder elkaar',
        options: ['Afrikaanse leiders werden gekozen', 'Europese landen verdeelden Afrika onder elkaar', 'de VOC werd opgeheven', 'Groot-Brittannie gaf India op']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Wat was een belangrijk gevolg van de Europese verdeling van Afrika?',
        explanation: 'Er ontstonden kunstmatige grenzen en langdurige spanningen.',
        correctAnswer: 'kunstmatige grenzen en langdurige spanningen',
        options: ['stabiele democratie overal', 'kunstmatige grenzen en langdurige spanningen', 'einde van alle handel', 'minder Europese invloed']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'In welke jaren vond de Conferentie van Berlijn plaats?',
        explanation: 'Dat was in 1884-1885.',
        correctAnswer: '1884-1885',
        options: ['1814-1815', '1830', '1871', '1884-1885']
      })
    ]
  },
  {
    moduleId: 45,
    summary: 'Oefenvragen bij paragraaf 5.4 over de verdeling van Afrika.',
    sections: [],
    questions: [
      question({
        topic: '5-4-afrika',
        prompt: 'Waar was Europese invloed rond 1800 vooral sterk aanwezig?',
        explanation: 'Vooral aan de kust.',
        correctAnswer: 'aan de kust',
        options: ['in het hele binnenland', 'aan de kust', 'alleen in het noorden', 'nergens']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Wat wilden Europese landen laten zien met kolonieen in Afrika?',
        explanation: 'Ze wilden hun macht en prestige tonen.',
        correctAnswer: 'hun macht en prestige',
        options: ['hun macht en prestige', 'hun zwakte', 'hun gelijkheid', 'hun neutraliteit']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Welk begrip past bij het snel opeisen van gebied door Europese landen?',
        explanation: 'Dat is de wedloop om Afrika.',
        correctAnswer: 'de wedloop om Afrika',
        options: ['restauratie', 'de wedloop om Afrika', 'het cultuurstelsel', 'de industrialisatie']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Wat was een probleem van de nieuwe grenzen in Afrika?',
        explanation: 'Ze sloten vaak niet aan bij bestaande volken en gebieden.',
        correctAnswer: 'ze hielden geen rekening met bestaande volken',
        options: ['ze waren te klein voor Europa', 'ze hielden geen rekening met bestaande volken', 'ze maakten alle landen rijk', 'ze werden door Afrikaanse leiders zelf gekozen']
      }),
      question({
        topic: '5-4-afrika',
        prompt: 'Waarom is 1884-1885 een belangrijk jaartal?',
        explanation: 'Toen vond de Conferentie van Berlijn plaats.',
        correctAnswer: 'vanwege de Conferentie van Berlijn',
        options: ['vanwege het ontstaan van Duits-Indie', 'vanwege de Conferentie van Berlijn', 'vanwege de Belgische Opstand', 'vanwege de val van de VOC']
      }),
      question({
        topic: '5-4-afrika',
        kind: 'open',
        prompt: 'Noem een gevolg van kolonisatie voor Afrika op langere termijn.',
        explanation: 'Bijvoorbeeld langdurige conflicten of politieke instabiliteit door kunstmatige grenzen.',
        correctAnswer: 'langdurige conflicten',
        difficulty: 3
      })
    ]
  },
  {
    moduleId: 46,
    summary: 'Toets bij paragraaf 5.4 over de wedloop om Afrika.',
    sections: [],
    questions: [
      question({
        topic: '5-4-toets',
        prompt: 'Welke oorzaak past het best bij de wedloop om Afrika?',
        explanation: 'Nationalisme en machtsstrijd speelden een grote rol.',
        correctAnswer: 'nationalisme en machtsstrijd',
        options: ['restauratie en democratisering', 'nationalisme en machtsstrijd', 'alleen religieuze vrijheid', 'een tekort aan havens in Europa']
      }),
      question({
        topic: '5-4-toets',
        kind: 'open',
        prompt: 'Noem een gevolg van de Europese verdeling van Afrika.',
        explanation: 'Bijvoorbeeld kunstmatige grenzen, geweld of langdurige conflicten.',
        correctAnswer: 'kunstmatige grenzen',
        difficulty: 3
      }),
      question({
        topic: '5-4-toets',
        prompt: 'Waarom was de Conferentie van Berlijn problematisch voor Afrikaanse volken?',
        explanation: 'Omdat Europese landen grenzen trokken zonder Afrikaanse inspraak.',
        correctAnswer: 'omdat grenzen zonder Afrikaanse inspraak werden getrokken',
        options: ['omdat Afrika onafhankelijk werd', 'omdat grenzen zonder Afrikaanse inspraak werden getrokken', 'omdat er geen handel meer mocht zijn', 'omdat alle koningen werden afgezet']
      }),
      question({
        topic: '5-4-toets',
        prompt: 'Welke combinatie klopt?',
        explanation: 'Conferentie van Berlijn hoort bij de verdeling van Afrika.',
        correctAnswer: 'Conferentie van Berlijn - verdeling van Afrika',
        options: ['Conferentie van Berlijn - verdeling van Afrika', 'Cultuurstelsel - Britse kolonie in India', 'Restauratie - afzetgebied', 'Modern imperialisme - herstel van oude vorsten']
      })
    ]
  }
];

const theoryOnlyModules = [1, 4, 31, 35, 38, 41, 44];

function replaceTheory(moduleId, sections) {
  db.prepare('DELETE FROM theory_sections WHERE module_id = ?').run(moduleId);

  const insert = db.prepare(`
    INSERT INTO theory_sections (module_id, heading, body_markdown, position)
    VALUES (?, ?, ?, ?)
  `);

  sections.forEach((section, index) => {
    insert.run(moduleId, section.heading, section.body, index + 1);
  });
}

function replaceQuestions(moduleId, questions) {
  db.prepare('DELETE FROM questions WHERE module_id = ?').run(moduleId);

  const insert = db.prepare(`
    INSERT INTO questions (
      module_id,
      topic,
      kind,
      prompt,
      explanation,
      difficulty,
      correct_answer,
      options_json,
      is_active
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)
  `);

  questions.forEach((entry) => {
    insert.run(
      moduleId,
      entry.topic,
      entry.kind,
      entry.prompt,
      entry.explanation,
      entry.difficulty,
      entry.correctAnswer,
      JSON.stringify(entry.options || [])
    );
  });
}

const transaction = db.transaction(() => {
  const updateModule = db.prepare(`
    UPDATE modules
    SET summary = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `);

  chapterContent.forEach((module) => {
    updateModule.run(module.summary, module.moduleId);
    replaceTheory(module.moduleId, module.sections);
    replaceQuestions(module.moduleId, module.questions);
  });

  theoryOnlyModules.forEach((moduleId) => {
    replaceQuestions(moduleId, []);
  });
});

transaction();

const summary = db.prepare(`
  SELECT modules.id, modules.title, modules.type,
    COUNT(DISTINCT theory_sections.id) AS theoryCount,
    COUNT(DISTINCT questions.id) AS questionCount
  FROM modules
  LEFT JOIN theory_sections ON theory_sections.module_id = modules.id
  LEFT JOIN questions ON questions.module_id = modules.id
  WHERE modules.id IN (${chapterContent.map((item) => item.moduleId).join(', ')})
  GROUP BY modules.id
  ORDER BY modules.id
`).all();

console.log(JSON.stringify(summary, null, 2));
