import path from 'node:path';
import { initializeDatabase } from '../server/db.js';
import { exportSnapshot, writeSnapshot } from '../server/seed.js';

const outputPath = process.argv[2]
  ? path.resolve(process.argv[2])
  : path.resolve(process.cwd(), 'seeds', 'base-seed.json');

const db = initializeDatabase();
const snapshot = exportSnapshot(db);

writeSnapshot(outputPath, snapshot);

console.log(`Database geëxporteerd naar ${outputPath}`);
