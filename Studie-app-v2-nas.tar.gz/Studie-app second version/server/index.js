import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase } from './db.js';
import { chooseAdaptiveQuestion, normalizeAnswer } from './adaptive.js';
import {
  clearSessionCookieValue,
  createSessionExpiry,
  createSessionToken,
  getSessionTokenFromRequest,
  publicUser,
  sessionCookieValue,
  verifyPassword
} from './auth.js';
import {
  buildSuggestedSections,
  deleteStoredImportFile,
  ensureImportsDir,
  extractTextFromFile,
  parseMultipartForm,
  slugify,
  storeUploadedFile
} from './imports.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '..');
const publicDir = path.join(projectRoot, 'public');

const app = express();
const db = initializeDatabase();
const port = Number(process.env.PORT || 3000);
const host = process.env.HOST || '0.0.0.0';

ensureImportsDir(projectRoot);

app.use(express.json());
app.use(express.static(publicDir));

app.use((request, _response, next) => {
  const sessionToken = getSessionTokenFromRequest(request);
  request.authUser = null;
  request.sessionToken = sessionToken;

  if (!sessionToken) {
    next();
    return;
  }

  const session = db.prepare(`
    SELECT users.id, users.username, users.display_name, users.role, users.is_active, sessions.expires_at
    FROM sessions
    INNER JOIN users ON users.id = sessions.user_id
    WHERE sessions.token = ?
  `).get(sessionToken);

  if (!session || Number(session.is_active) !== 1 || new Date(session.expires_at).getTime() <= Date.now()) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(sessionToken);
    next();
    return;
  }

  request.authUser = session;
  next();
});

function parseOptions(optionsJson) {
  try {
    return JSON.parse(optionsJson || '[]');
  } catch {
    return [];
  }
}

function normalizeQuestionOptions(optionsJson) {
  return parseOptions(optionsJson)
    .map((option) => String(option || '').trim())
    .filter((option) => option && !isPlaceholderOption(option));
}

function resolveCorrectAnswer(row) {
  const options = normalizeQuestionOptions(row.options_json);
  const raw = String(row.correct_answer || '').trim();

  if (row.kind === 'multiple_choice' && /^\d+$/.test(raw)) {
    const index = Number(raw);
    return options[index] || raw;
  }

  return raw;
}

function mapQuestion(row) {
  return {
    id: row.id,
    moduleId: row.module_id,
    topic: row.topic,
    kind: row.kind,
    prompt: row.prompt,
    explanation: row.explanation,
    difficulty: row.difficulty,
    correctAnswer: resolveCorrectAnswer(row),
    options: normalizeQuestionOptions(row.options_json)
  };
}

function isPlaceholderOption(option) {
  return /^q\d+_opt\d+$/i.test(String(option || '').trim());
}

function isUsablePracticeQuestion(row) {
  const prompt = String(row.prompt || '').trim();
  const options = normalizeQuestionOptions(row.options_json);
  const correctAnswer = resolveCorrectAnswer(row);

  if (!prompt) {
    return false;
  }

  if (row.kind === 'multiple_choice') {
    if (options.length < 2) {
      return false;
    }

    if (!correctAnswer) {
      return false;
    }
  }

  return true;
}

function listSubjects() {
  return db.prepare(`
    SELECT
      subjects.id,
      subjects.slug,
      subjects.title,
      subjects.description,
      subjects.accent_color AS accentColor,
      COUNT(DISTINCT modules.id) AS moduleCount,
      COUNT(DISTINCT questions.id) AS questionCount
    FROM subjects
    LEFT JOIN modules ON modules.subject_id = subjects.id
    LEFT JOIN questions ON questions.module_id = modules.id
    GROUP BY subjects.id
    ORDER BY subjects.title
  `).all();
}

function getSubjectBySlug(slug) {
  const subject = db.prepare(`
    SELECT id, slug, title, description, accent_color AS accentColor
    FROM subjects
    WHERE slug = ?
  `).get(slug);

  if (!subject) {
    return null;
  }

  const modules = db.prepare(`
    SELECT id, slug, title, type, topic, summary, position
    FROM modules
    WHERE subject_id = ?
    ORDER BY position, title
  `).all(subject.id).map((module) => {
    const questions = db.prepare(`
      SELECT kind, prompt, options_json
      FROM questions
      WHERE module_id = ?
        AND is_active = 1
    `).all(module.id);

    return {
      ...module,
      questionCount: questions.length,
      usableQuestionCount: questions.filter(isUsablePracticeQuestion).length
    };
  });

  return { ...subject, modules };
}

function adminCatalog() {
  const subjects = db.prepare(`
    SELECT id, slug, title, description, accent_color AS accentColor
    FROM subjects
    ORDER BY title
  `).all();

  return subjects.map((subject) => {
    const modules = db.prepare(`
      SELECT id, slug, title, type, topic, summary, position
      FROM modules
      WHERE subject_id = ?
      ORDER BY position, title
    `).all(subject.id);

    const nestedModules = modules.map((module) => ({
      ...module,
      theorySections: db.prepare(`
        SELECT id, heading, body_markdown AS body, position
        FROM theory_sections
        WHERE module_id = ?
        ORDER BY position, id
      `).all(module.id),
      questions: db.prepare(`
        SELECT id, topic, kind, prompt, explanation, difficulty, correct_answer AS correctAnswer, options_json AS optionsJson
        FROM questions
        WHERE module_id = ?
        ORDER BY id
      `).all(module.id).map((question) => ({
        ...question,
        options: parseOptions(question.optionsJson)
      }))
    }));

    return {
      ...subject,
      modules: nestedModules
    };
  });
}

function parseSuggestedSections(sectionsJson) {
  try {
    return JSON.parse(sectionsJson || '[]');
  } catch {
    return [];
  }
}

function listImports() {
  return db.prepare(`
    SELECT
      imports.id,
      imports.subject_id AS subjectId,
      subjects.title AS subjectTitle,
      subjects.slug AS subjectSlug,
      imports.title,
      imports.module_slug AS moduleSlug,
      imports.module_topic AS moduleTopic,
      imports.module_summary AS moduleSummary,
      imports.original_filename AS originalFilename,
      imports.mime_type AS mimeType,
      imports.source_format AS sourceFormat,
      imports.raw_text AS rawText,
      imports.suggested_sections_json AS suggestedSectionsJson,
      imports.status,
      imports.imported_module_id AS importedModuleId,
      imports.created_at AS createdAt
    FROM imports
    INNER JOIN subjects ON subjects.id = imports.subject_id
    ORDER BY imports.created_at DESC, imports.id DESC
  `).all().map((row) => ({
    ...row,
    suggestedSections: parseSuggestedSections(row.suggestedSectionsJson)
  }));
}

function parseImportPayload(request) {
  const contentType = request.headers['content-type'] || '';
  const multipart = parseMultipartForm(request.body, contentType);
  const { fields, file } = multipart;

  if (!file) {
    throw new Error('Kies een bestand om te uploaden.');
  }

  const extension = path.extname(file.filename).toLowerCase();
  const sourceFormat = extension === '.docx' ? 'docx' : extension === '.txt' ? 'txt' : '';
  if (!sourceFormat) {
    throw new Error('Alleen .docx en .txt worden ondersteund.');
  }

  return {
    fields,
    file,
    sourceFormat
  };
}

function requireAuth(request, response, next) {
  if (!request.authUser) {
    response.status(401).json({ error: 'Log eerst in om verder te gaan.' });
    return;
  }

  next();
}

function requireAdmin(request, response, next) {
  if (!request.authUser) {
    response.status(401).json({ error: 'Log eerst in als beheerder.' });
    return;
  }

  if (request.authUser.role !== 'admin') {
    response.status(403).json({ error: 'Alleen beheerders hebben toegang tot deze functie.' });
    return;
  }

  next();
}

app.get('/api/health', (_request, response) => {
  response.json({ ok: true });
});

app.get('/api/auth/session', (request, response) => {
  response.json({ user: publicUser(request.authUser) });
});

app.post('/api/auth/login', (request, response) => {
  const { username, password, target = 'student' } = request.body || {};

  if (!username || !password) {
    response.status(400).json({ error: 'Gebruikersnaam en wachtwoord zijn verplicht.' });
    return;
  }

  const user = db.prepare(`
    SELECT id, username, password_hash, display_name, role, is_active
    FROM users
    WHERE username = ?
  `).get(String(username).trim());

  if (!user || Number(user.is_active) !== 1 || !verifyPassword(password, user.password_hash)) {
    response.status(401).json({ error: 'Onjuiste gebruikersnaam of wachtwoord.' });
    return;
  }

  if (target === 'admin' && user.role !== 'admin') {
    response.status(403).json({ error: 'Dit account heeft geen beheerrechten.' });
    return;
  }

  const token = createSessionToken();
  const expiresAt = createSessionExpiry();

  db.prepare(`
    INSERT INTO sessions (user_id, token, expires_at)
    VALUES (?, ?, ?)
  `).run(user.id, token, expiresAt);

  response.setHeader('Set-Cookie', sessionCookieValue(token));
  response.json({ user: publicUser(user) });
});

app.post('/api/auth/logout', (request, response) => {
  if (request.sessionToken) {
    db.prepare('DELETE FROM sessions WHERE token = ?').run(request.sessionToken);
  }

  response.setHeader('Set-Cookie', clearSessionCookieValue());
  response.json({ ok: true });
});

app.get('/api/subjects', requireAuth, (_request, response) => {
  response.json(listSubjects());
});

app.get('/api/subjects/:slug', requireAuth, (request, response) => {
  const subject = getSubjectBySlug(request.params.slug);

  if (!subject) {
    response.status(404).json({ error: 'Vak niet gevonden.' });
    return;
  }

  response.json(subject);
});

app.get('/api/modules/:moduleId/theory', requireAuth, (request, response) => {
  const sections = db.prepare(`
    SELECT id, heading, body_markdown AS body, position
    FROM theory_sections
    WHERE module_id = ?
    ORDER BY position, id
  `).all(request.params.moduleId);

  response.json(sections);
});

app.post('/api/practice/next', requireAuth, (request, response) => {
  const { subjectSlug, moduleId } = request.body || {};
  const userId = String(request.authUser.id);

  if (!subjectSlug) {
    response.status(400).json({ error: 'subjectSlug is verplicht.' });
    return;
  }

  const questions = moduleId
    ? db.prepare(`
      SELECT questions.*
      FROM questions
      INNER JOIN modules ON modules.id = questions.module_id
      INNER JOIN subjects ON subjects.id = modules.subject_id
      WHERE subjects.slug = ?
        AND modules.id = ?
        AND questions.is_active = 1
        AND modules.type IN ('practice', 'assessment')
    `).all(subjectSlug, moduleId).filter(isUsablePracticeQuestion)
    : db.prepare(`
      SELECT questions.*
      FROM questions
      INNER JOIN modules ON modules.id = questions.module_id
      INNER JOIN subjects ON subjects.id = modules.subject_id
      WHERE subjects.slug = ?
        AND questions.is_active = 1
        AND modules.type = 'practice'
    `).all(subjectSlug).filter(isUsablePracticeQuestion);

  const attempts = db.prepare(`
    SELECT question_id, topic, is_correct
    FROM attempts
    WHERE user_id = ?
      AND subject_slug = ?
    ORDER BY created_at DESC
    LIMIT 100
  `).all(userId, subjectSlug);

  const nextQuestion = chooseAdaptiveQuestion(questions.map(mapQuestion), attempts);
  if (!nextQuestion) {
    response.status(404).json({ error: 'Geen vragen gevonden voor dit vak.' });
    return;
  }

  response.json({
    question: {
      id: nextQuestion.id,
      moduleId: nextQuestion.moduleId,
      topic: nextQuestion.topic,
      kind: nextQuestion.kind,
      prompt: nextQuestion.prompt,
      explanation: nextQuestion.explanation,
      difficulty: nextQuestion.difficulty,
      options: nextQuestion.options
    }
  });
});

app.post('/api/attempts', requireAuth, (request, response) => {
  const {
    questionId,
    subjectSlug,
    answer
  } = request.body || {};
  const userId = String(request.authUser.id);

  if (!questionId || !subjectSlug) {
    response.status(400).json({ error: 'questionId en subjectSlug zijn verplicht.' });
    return;
  }

  const question = db.prepare(`
    SELECT questions.*, modules.topic AS module_topic
    FROM questions
    INNER JOIN modules ON modules.id = questions.module_id
    WHERE questions.id = ?
  `).get(questionId);

  if (!question) {
    response.status(404).json({ error: 'Vraag niet gevonden.' });
    return;
  }

  const options = normalizeQuestionOptions(question.options_json);
  const submittedAnswer = question.kind === 'multiple_choice' && /^\d+$/.test(String(answer ?? '').trim())
    ? (options[Number(answer)] || '')
    : String(answer ?? '');
  const correctAnswer = resolveCorrectAnswer(question);
  const isCorrect = normalizeAnswer(submittedAnswer) === normalizeAnswer(correctAnswer) ? 1 : 0;

  db.prepare(`
    INSERT INTO attempts (user_id, question_id, subject_slug, topic, is_correct, answer_text)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(
    userId,
    questionId,
    subjectSlug,
    question.topic || question.module_topic,
    isCorrect,
    submittedAnswer
  );

  response.json({
    isCorrect: Boolean(isCorrect),
    correctAnswer,
    explanation: question.explanation
  });
});

app.get('/api/progress/:subjectSlug', requireAuth, (request, response) => {
  const userId = String(request.authUser.id);
  const subjectSlug = request.params.subjectSlug;

  const summary = db.prepare(`
    SELECT
      COUNT(*) AS totalAttempts,
      SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) AS correctAttempts
    FROM attempts
    WHERE user_id = ?
      AND subject_slug = ?
  `).get(userId, subjectSlug);

  const topics = db.prepare(`
    SELECT
      topic,
      COUNT(*) AS totalAttempts,
      SUM(CASE WHEN is_correct = 1 THEN 1 ELSE 0 END) AS correctAttempts
    FROM attempts
    WHERE user_id = ?
      AND subject_slug = ?
    GROUP BY topic
    ORDER BY topic
  `).all(userId, subjectSlug);

  response.json({
    totalAttempts: summary.totalAttempts || 0,
    correctAttempts: summary.correctAttempts || 0,
    topics
  });
});

app.get('/api/admin/catalog', requireAdmin, (_request, response) => {
  response.json(adminCatalog());
});

app.get('/api/admin/imports', requireAdmin, (_request, response) => {
  response.json(listImports());
});

app.post('/api/admin/imports', requireAdmin, express.raw({ type: () => true, limit: '20mb' }), (request, response) => {
  let storedFilename = null;

  try {
    const { fields, file, sourceFormat } = parseImportPayload(request);
    const subjectId = Number(fields.subjectId || 0);
    const title = String(fields.title || '').trim();
    const moduleSlug = slugify(fields.moduleSlug || title);
    const moduleTopic = slugify(fields.moduleTopic || title);
    const moduleSummary = String(fields.moduleSummary || title || 'Geimporteerde theorie').trim();

    if (!subjectId || !title || !moduleSlug || !moduleTopic) {
      response.status(400).json({ error: 'subjectId, title, moduleSlug en moduleTopic zijn verplicht.' });
      return;
    }

    const subject = db.prepare('SELECT id FROM subjects WHERE id = ?').get(subjectId);
    if (!subject) {
      response.status(404).json({ error: 'Vak niet gevonden voor deze import.' });
      return;
    }

    const storedFile = storeUploadedFile(projectRoot, file.filename, file.buffer);
    storedFilename = storedFile.storedFilename;

    const rawText = extractTextFromFile(storedFile.filePath, sourceFormat);
    const suggestedSections = buildSuggestedSections(rawText, title);

    const result = db.prepare(`
      INSERT INTO imports (
        subject_id,
        title,
        module_slug,
        module_topic,
        module_summary,
        original_filename,
        stored_filename,
        mime_type,
        source_format,
        raw_text,
        suggested_sections_json
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      subjectId,
      title,
      moduleSlug,
      moduleTopic,
      moduleSummary,
      file.filename,
      storedFilename,
      file.mimeType,
      sourceFormat,
      rawText,
      JSON.stringify(suggestedSections)
    );

    response.status(201).json({
      id: result.lastInsertRowid,
      sectionCount: suggestedSections.length,
      characterCount: rawText.length
    });
  } catch (error) {
    if (storedFilename) {
      deleteStoredImportFile(projectRoot, storedFilename);
    }

    response.status(400).json({ error: error.message || 'Import upload mislukt.' });
  }
});

app.post('/api/admin/imports/:id/commit', requireAdmin, (request, response) => {
  const importItem = db.prepare(`
    SELECT *
    FROM imports
    WHERE id = ?
  `).get(request.params.id);

  if (!importItem) {
    response.status(404).json({ error: 'Import niet gevonden.' });
    return;
  }

  if (importItem.status === 'imported') {
    response.status(400).json({ error: 'Deze import is al omgezet naar een module.' });
    return;
  }

  const sections = parseSuggestedSections(importItem.suggested_sections_json);
  if (!sections.length) {
    response.status(400).json({ error: 'Deze import bevat geen theorieblokken om op te slaan.' });
    return;
  }

  const slugExists = db.prepare('SELECT id FROM modules WHERE slug = ?').get(importItem.module_slug);
  if (slugExists) {
    response.status(400).json({ error: 'De module-slug uit deze import bestaat al. Kies een andere slug.' });
    return;
  }

  const transaction = db.transaction(() => {
    const nextPosition = db.prepare(`
      SELECT COALESCE(MAX(position), 0) + 1 AS nextPosition
      FROM modules
      WHERE subject_id = ?
    `).get(importItem.subject_id).nextPosition;

    const moduleResult = db.prepare(`
      INSERT INTO modules (subject_id, slug, title, type, topic, summary, position)
      VALUES (?, ?, ?, 'theory', ?, ?, ?)
    `).run(
      importItem.subject_id,
      importItem.module_slug,
      importItem.title,
      importItem.module_topic,
      importItem.module_summary,
      nextPosition
    );

    const moduleId = moduleResult.lastInsertRowid;
    const insertTheory = db.prepare(`
      INSERT INTO theory_sections (module_id, heading, body_markdown, position)
      VALUES (?, ?, ?, ?)
    `);

    sections.forEach((section, index) => {
      insertTheory.run(
        moduleId,
        section.heading,
        section.body,
        Number(section.position || index + 1)
      );
    });

    db.prepare(`
      UPDATE imports
      SET status = 'imported', imported_module_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(moduleId, importItem.id);

    return {
      moduleId,
      sectionCount: sections.length
    };
  });

  const result = transaction();
  response.json({
    ok: true,
    moduleId: result.moduleId,
    sectionCount: result.sectionCount
  });
});

app.delete('/api/admin/imports/:id', requireAdmin, (request, response) => {
  const importItem = db.prepare('SELECT stored_filename AS storedFilename FROM imports WHERE id = ?').get(request.params.id);
  if (!importItem) {
    response.status(404).json({ error: 'Import niet gevonden.' });
    return;
  }

  db.prepare('DELETE FROM imports WHERE id = ?').run(request.params.id);
  deleteStoredImportFile(projectRoot, importItem.storedFilename);
  response.json({ ok: true });
});

app.post('/api/admin/subjects', requireAdmin, (request, response) => {
  const { slug, title, description, accentColor } = request.body || {};

  if (!slug || !title || !description || !accentColor) {
    response.status(400).json({ error: 'slug, title, description en accentColor zijn verplicht.' });
    return;
  }

  const result = db.prepare(`
    INSERT INTO subjects (slug, title, description, accent_color)
    VALUES (?, ?, ?, ?)
  `).run(slug, title, description, accentColor);

  response.status(201).json({ id: result.lastInsertRowid });
});

app.put('/api/admin/subjects/:id', requireAdmin, (request, response) => {
  const { slug, title, description, accentColor } = request.body || {};

  db.prepare(`
    UPDATE subjects
    SET slug = ?, title = ?, description = ?, accent_color = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(slug, title, description, accentColor, request.params.id);

  response.json({ ok: true });
});

app.delete('/api/admin/subjects/:id', requireAdmin, (request, response) => {
  db.prepare('DELETE FROM subjects WHERE id = ?').run(request.params.id);
  response.json({ ok: true });
});

app.post('/api/admin/modules', requireAdmin, (request, response) => {
  const { subjectId, slug, title, type, topic, summary, position = 0 } = request.body || {};

  const result = db.prepare(`
    INSERT INTO modules (subject_id, slug, title, type, topic, summary, position)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(subjectId, slug, title, type, topic, summary, position);

  response.status(201).json({ id: result.lastInsertRowid });
});

app.put('/api/admin/modules/:id', requireAdmin, (request, response) => {
  const { slug, title, type, topic, summary, position = 0 } = request.body || {};

  db.prepare(`
    UPDATE modules
    SET slug = ?, title = ?, type = ?, topic = ?, summary = ?, position = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(slug, title, type, topic, summary, position, request.params.id);

  response.json({ ok: true });
});

app.delete('/api/admin/modules/:id', requireAdmin, (request, response) => {
  db.prepare('DELETE FROM modules WHERE id = ?').run(request.params.id);
  response.json({ ok: true });
});

app.post('/api/admin/theory-sections', requireAdmin, (request, response) => {
  const { moduleId, heading, body, position = 0 } = request.body || {};

  const result = db.prepare(`
    INSERT INTO theory_sections (module_id, heading, body_markdown, position)
    VALUES (?, ?, ?, ?)
  `).run(moduleId, heading, body, position);

  response.status(201).json({ id: result.lastInsertRowid });
});

app.put('/api/admin/theory-sections/:id', requireAdmin, (request, response) => {
  const { heading, body, position = 0 } = request.body || {};

  db.prepare(`
    UPDATE theory_sections
    SET heading = ?, body_markdown = ?, position = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(heading, body, position, request.params.id);

  response.json({ ok: true });
});

app.delete('/api/admin/theory-sections/:id', requireAdmin, (request, response) => {
  db.prepare('DELETE FROM theory_sections WHERE id = ?').run(request.params.id);
  response.json({ ok: true });
});

app.post('/api/admin/questions', requireAdmin, (request, response) => {
  const { moduleId, topic, kind, prompt, explanation, difficulty, correctAnswer, options = [] } = request.body || {};

  const result = db.prepare(`
    INSERT INTO questions (module_id, topic, kind, prompt, explanation, difficulty, correct_answer, options_json)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run(moduleId, topic, kind, prompt, explanation, Number(difficulty || 1), correctAnswer, JSON.stringify(options));

  response.status(201).json({ id: result.lastInsertRowid });
});

app.put('/api/admin/questions/:id', requireAdmin, (request, response) => {
  const { topic, kind, prompt, explanation, difficulty, correctAnswer, options = [], isActive = true } = request.body || {};

  db.prepare(`
    UPDATE questions
    SET topic = ?, kind = ?, prompt = ?, explanation = ?, difficulty = ?, correct_answer = ?, options_json = ?, is_active = ?, updated_at = CURRENT_TIMESTAMP
    WHERE id = ?
  `).run(topic, kind, prompt, explanation, Number(difficulty || 1), correctAnswer, JSON.stringify(options), isActive ? 1 : 0, request.params.id);

  response.json({ ok: true });
});

app.delete('/api/admin/questions/:id', requireAdmin, (request, response) => {
  db.prepare('DELETE FROM questions WHERE id = ?').run(request.params.id);
  response.json({ ok: true });
});

app.get('*', (_request, response) => {
  response.sendFile(path.join(publicDir, 'index.html'));
});

if (process.env.NO_LISTEN !== '1') {
  app.listen(port, host, () => {
    console.log(`Studie-app second version draait op http://${host}:${port}`);
  });
}

export { app, db };
