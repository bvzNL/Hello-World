const state = {
  subjects: [],
  activeSubject: null,
  activeTheoryModuleId: null,
  activePracticeModuleId: null,
  activePracticeModuleTitle: '',
  practiceQuestion: null,
  feedback: null,
  user: null
};

const authShell = document.getElementById('authShell');
const appShell = document.getElementById('appShell');
const loginForm = document.getElementById('loginForm');
const loginFeedback = document.getElementById('loginFeedback');
const logoutButton = document.getElementById('logoutButton');
const sessionLabel = document.getElementById('sessionLabel');
const subjectsList = document.getElementById('subjectsList');
const subjectTitle = document.getElementById('subjectTitle');
const subjectDescription = document.getElementById('subjectDescription');
const moduleSelector = document.getElementById('moduleSelector');
const theorySections = document.getElementById('theorySections');
const theoryMeta = document.getElementById('theoryMeta');
const practiceHeading = document.getElementById('practiceHeading');
const practiceCard = document.getElementById('practiceCard');
const practiceMeta = document.getElementById('practiceMeta');
const progressSummary = document.getElementById('progressSummary');

async function api(pathname, options = {}) {
  const response = await fetch(pathname, {
    headers: {
      'Content-Type': 'application/json'
    },
    credentials: 'same-origin',
    ...options
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Onbekende fout' }));
    if (response.status === 401 && pathname !== '/api/auth/login') {
      setLoggedOutView('Je sessie is verlopen. Log opnieuw in.');
    }
    const message = new Error(error.error || 'Onbekende fout');
    message.status = response.status;
    throw message;
  }

  return response.json();
}

function setAuthenticatedView(user) {
  state.user = user;
  authShell.classList.add('hidden');
  appShell.classList.remove('hidden');
  sessionLabel.textContent = `${user.displayName} · ${user.role === 'admin' ? 'beheerder' : 'leerling'}`;
}

function setLoggedOutView(message = 'Log in om verder te gaan.') {
  state.user = null;
  authShell.classList.remove('hidden');
  appShell.classList.add('hidden');
  loginFeedback.textContent = message;
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function normalizeWhitespace(text) {
  return String(text || '')
    .replace(/\r/g, '')
    .replace(/[ \t]+\n/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function formatStudyText(text) {
  let value = normalizeWhitespace(text)
    .replace(/\\\(([\s\S]*?)\\\)/g, '$1')
    .replace(/\\\[([\s\S]*?)\\\]/g, '$1')
    .replace(/\\dfrac\{([^{}]+)\}\{([^{}]+)\}/g, '$1/$2')
    .replace(/\\frac\{([^{}]+)\}\{([^{}]+)\}/g, '$1/$2')
    .replace(/\\times/g, '×')
    .replace(/\\div/g, '÷')
    .replace(/\\cdot/g, '·')
    .replace(/\\approx/g, '≈')
    .replace(/\\Rightarrow/g, '→')
    .replace(/\\Leftrightarrow/g, '⇔')
    .replace(/\\geq/g, '≥')
    .replace(/\\leq/g, '≤')
    .replace(/\\sqrt\{([^{}]+)\}/g, '√($1)')
    .replace(/\\text\{([^{}]+)\}/g, '$1')
    .replace(/\^\{([^{}]+)\}/g, '^$1')
    .replace(/_\{([^{}]+)\}/g, '_$1')
    .replace(/\\[a-zA-Z]+/g, '')
    .replace(/[{}]/g, '')
    .replace(/\s+([,.;:!?])/g, '$1')
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  return escapeHtml(value).replace(/\n/g, '<br>');
}

function formatTopicLabel(topic) {
  return String(topic || '')
    .replace(/-/g, ' ')
    .replace(/\b\w/g, (match) => match.toUpperCase());
}

function deriveGroupLabel(module) {
  return String(module.title || '')
    .replace(/\s+–\s+(Theorie|Oefeningen|Toets)$/i, '')
    .trim() || formatTopicLabel(module.topic);
}

function groupModules(modules) {
  const groups = [];
  const map = new Map();

  modules.forEach((module) => {
    const isStandalonePractice = module.type === 'practice' && !/(chapitre|hoofdstuk|^\d+-\d+$)/i.test(module.topic);
    const key = isStandalonePractice ? `standalone-${module.id}` : module.topic;

    if (!map.has(key)) {
      map.set(key, {
        key,
        label: deriveGroupLabel(module),
        summary: module.summary,
        theory: null,
        practice: null,
        assessment: null,
        standalone: isStandalonePractice
      });
      groups.push(map.get(key));
    }

    const group = map.get(key);
    group.summary = group.summary || module.summary;
    group[module.type] = module;
  });

  return groups;
}

function resetTheoryState() {
  state.activeTheoryModuleId = null;
  theoryMeta.textContent = 'Open een theorie-onderdeel om de uitleg te lezen.';
  theorySections.className = 'theory-sections empty-state';
  theorySections.textContent = 'Kies een theorie-onderdeel.';
}

function resetPracticeState(message = 'Kies een onderdeel om te beginnen.') {
  state.activePracticeModuleId = null;
  state.activePracticeModuleTitle = '';
  state.practiceQuestion = null;
  state.feedback = null;
  practiceHeading.textContent = 'Oefenen';
  practiceMeta.textContent = 'Kies een oefenonderdeel of woordenlijst.';
  practiceCard.innerHTML = `<div class="empty-state">${escapeHtml(message)}</div>`;
}

function getModuleCardTitle(module) {
  if (!module) {
    return 'Oefenen';
  }

  if (module.type === 'assessment') {
    return 'Toets';
  }

  return /(woordenschat|werkwoorden)/i.test(module.title || '') ? module.title : 'Oefenen';
}

function getPracticeIntro(module) {
  if (!module) {
    return 'Kies een oefenonderdeel of woordenlijst.';
  }

  if (module.type === 'assessment') {
    return 'Beantwoord de toetsvragen van dit onderdeel.';
  }

  if (/(woordenschat|werkwoorden)/i.test(module.title || '')) {
    return `Open ${module.title.toLowerCase()} en oefen gericht per vraag.`;
  }

  return `Oefen de vragen van ${module.title.toLowerCase()}.`;
}

function renderSubjects() {
  subjectsList.innerHTML = '';

  state.subjects.forEach((subject) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'subject-button';
    button.style.setProperty('--accent', subject.accentColor);
    if (state.activeSubject?.slug === subject.slug) {
      button.classList.add('active');
    }

    button.innerHTML = `
      <span class="subject-meta">${subject.moduleCount} modules · ${subject.questionCount} vragen</span>
      <strong>${escapeHtml(subject.title)}</strong>
      <div class="subject-description">${escapeHtml(subject.description)}</div>
    `;

    button.addEventListener('click', () => selectSubject(subject.slug));
    subjectsList.appendChild(button);
  });
}

function renderTheory(sections) {
  if (!sections.length) {
    theorySections.className = 'theory-sections empty-state';
    theorySections.textContent = 'Voor dit onderdeel is nog geen theorie ingevoerd.';
    return;
  }

  theorySections.className = 'theory-sections';
  theorySections.innerHTML = sections.map((section) => `
    <section class="theory-section">
      <h4>${escapeHtml(section.heading)}</h4>
      <div class="theory-body">${formatStudyText(section.body)}</div>
    </section>
  `).join('');
}

async function loadTheoryModule(module) {
  state.activeTheoryModuleId = module.id;
  theoryMeta.textContent = module.title;
  const sections = await api(`/api/modules/${module.id}/theory`);
  renderModuleBrowser();
  renderTheory(sections);
}

function renderModuleButton(module, label, className, onClick, active, disabledReason) {
  if (!module) {
    return '';
  }

  const disabled = module.type !== 'theory' && module.usableQuestionCount === 0;
  const reason = disabled ? (disabledReason || 'Nog niet beschikbaar') : '';

  return `
    <button
      type="button"
      class="module-action ${className}${active ? ' active' : ''}"
      data-module-id="${module.id}"
      ${disabled ? 'disabled' : ''}
      ${reason ? `title="${escapeHtml(reason)}"` : ''}
    >
      ${escapeHtml(label)}
    </button>
  `;
}

function renderModuleBrowser() {
  if (!state.activeSubject?.modules?.length) {
    moduleSelector.className = 'module-browser empty-state';
    moduleSelector.textContent = 'Kies eerst een vak.';
    return;
  }

  const groups = groupModules(state.activeSubject.modules);
  moduleSelector.className = 'module-browser';
  moduleSelector.innerHTML = groups.map((group) => `
    <section class="module-group">
      <div class="module-group-head">
        <h4>${escapeHtml(group.label)}</h4>
        <p>${escapeHtml(group.summary || '')}</p>
      </div>
      <div class="module-actions">
        ${renderModuleButton(
          group.theory,
          'Theorie',
          'theory-action',
          'theory',
          group.theory?.id === state.activeTheoryModuleId,
          ''
        )}
        ${renderModuleButton(
          group.practice,
          group.standalone ? group.label : 'Oefenen',
          'practice-action',
          'practice',
          group.practice?.id === state.activePracticeModuleId,
          'Voor dit onderdeel zijn nog geen bruikbare oefenvragen beschikbaar.'
        )}
        ${renderModuleButton(
          group.assessment,
          'Toets',
          'assessment-action',
          'assessment',
          group.assessment?.id === state.activePracticeModuleId,
          'Voor deze toets zijn nog geen bruikbare vragen beschikbaar.'
        )}
      </div>
    </section>
  `).join('');

  moduleSelector.querySelectorAll('.module-action').forEach((button) => {
    const moduleId = Number(button.dataset.moduleId);
    const module = state.activeSubject.modules.find((item) => item.id === moduleId);
    if (!module || button.disabled) {
      return;
    }

    button.addEventListener('click', async () => {
      if (module.type === 'theory') {
        await loadTheoryModule(module);
        return;
      }

      await loadPracticeModule(module);
    });
  });
}

function renderPractice() {
  if (!state.practiceQuestion) {
    practiceCard.innerHTML = '<div class="empty-state">Kies een oefenonderdeel om te beginnen.</div>';
    return;
  }

  const question = state.practiceQuestion;
  const feedbackHtml = state.feedback ? `
    <div class="feedback ${state.feedback.isCorrect ? 'correct' : 'wrong'}">
      <strong>${state.feedback.isCorrect ? 'Goed gedaan.' : 'Nog niet goed.'}</strong>
      <div>${formatStudyText(state.feedback.explanation)}</div>
      ${state.feedback.isCorrect ? '' : `<div>Juist antwoord: <strong>${escapeHtml(state.feedback.correctAnswer)}</strong></div>`}
    </div>
  ` : '';

  if (question.kind === 'multiple_choice') {
    practiceCard.innerHTML = `
      <div>
        <span class="topic-chip">${escapeHtml(formatTopicLabel(question.topic))} · moeilijkheid ${question.difficulty}</span>
      </div>
      <div class="question-prompt">${formatStudyText(question.prompt)}</div>
      <div class="choice-list">
        ${question.options.map((option, index) => `
          <button type="button" class="choice-button" data-answer="${index}">${formatStudyText(option)}</button>
        `).join('')}
      </div>
      ${feedbackHtml}
      <div class="action-row">
        <button type="button" class="action-button secondary" id="nextQuestionButton">Volgende vraag</button>
      </div>
    `;

    practiceCard.querySelectorAll('.choice-button').forEach((button) => {
      button.addEventListener('click', () => submitAttempt(button.dataset.answer));
    });
  } else {
    practiceCard.innerHTML = `
      <div>
        <span class="topic-chip">${escapeHtml(formatTopicLabel(question.topic))} · moeilijkheid ${question.difficulty}</span>
      </div>
      <div class="question-prompt">${formatStudyText(question.prompt)}</div>
      <input class="answer-input" id="openAnswerInput" placeholder="Typ je antwoord" />
      ${feedbackHtml}
      <div class="action-row">
        <button type="button" class="action-button" id="submitAnswerButton">Controleer antwoord</button>
        <button type="button" class="action-button secondary" id="nextQuestionButton">Volgende vraag</button>
      </div>
    `;

    practiceCard.querySelector('#submitAnswerButton').addEventListener('click', () => {
      const value = document.getElementById('openAnswerInput').value;
      submitAttempt(value);
    });
  }

  practiceCard.querySelector('#nextQuestionButton').addEventListener('click', loadNextQuestion);
}

function renderProgress(progress) {
  if (!progress.totalAttempts) {
    progressSummary.className = 'empty-state';
    progressSummary.textContent = 'Nog geen pogingen opgeslagen voor dit vak.';
    return;
  }

  const topicsHtml = progress.topics.map((topic) => {
    const pct = topic.totalAttempts ? Math.round((topic.correctAttempts / topic.totalAttempts) * 100) : 0;
    return `
      <div class="progress-item">
        <div>
          <strong>${escapeHtml(formatTopicLabel(topic.topic))}</strong>
          <div>${topic.correctAttempts} van ${topic.totalAttempts} goed</div>
        </div>
        <div class="progress-bar">
          <div class="progress-fill" style="width: ${pct}%"></div>
        </div>
      </div>
    `;
  }).join('');

  progressSummary.className = 'progress-list';
  progressSummary.innerHTML = topicsHtml;
}

async function loadProgress() {
  if (!state.activeSubject) {
    return;
  }

  const progress = await api(`/api/progress/${state.activeSubject.slug}`);
  renderProgress(progress);
}

async function loadPracticeModule(module) {
  state.activePracticeModuleId = module.id;
  state.activePracticeModuleTitle = module.title;
  state.feedback = null;
  practiceHeading.textContent = getModuleCardTitle(module);
  practiceMeta.textContent = module.title;
  renderModuleBrowser();
  await loadNextQuestion();
}

async function loadNextQuestion() {
  if (!state.activeSubject || !state.activePracticeModuleId) {
    return;
  }

  state.feedback = null;

  try {
    const payload = await api('/api/practice/next', {
      method: 'POST',
      body: JSON.stringify({
        subjectSlug: state.activeSubject.slug,
        moduleId: state.activePracticeModuleId
      })
    });

    state.practiceQuestion = payload.question;
    const selectedModule = state.activeSubject.modules.find((item) => item.id === state.activePracticeModuleId);
    practiceHeading.textContent = getModuleCardTitle(selectedModule);
    practiceMeta.textContent = selectedModule ? getPracticeIntro(selectedModule) : state.activePracticeModuleTitle;
    renderPractice();
  } catch (error) {
    state.practiceQuestion = null;
    practiceCard.innerHTML = `<div class="empty-state">${escapeHtml(error.message)}</div>`;
  }
}

async function submitAttempt(answer) {
  if (!state.practiceQuestion || !state.activeSubject) {
    return;
  }

  const feedback = await api('/api/attempts', {
    method: 'POST',
    body: JSON.stringify({
      subjectSlug: state.activeSubject.slug,
      questionId: state.practiceQuestion.id,
      answer
    })
  });

  state.feedback = feedback;
  renderPractice();
  await loadProgress();
}

async function selectSubject(slug) {
  const subject = await api(`/api/subjects/${slug}`);
  state.activeSubject = subject;
  state.activeTheoryModuleId = null;
  state.activePracticeModuleId = null;
  state.activePracticeModuleTitle = '';
  state.practiceQuestion = null;
  state.feedback = null;
  subjectTitle.textContent = subject.title;
  subjectDescription.textContent = subject.description;
  renderSubjects();
  resetTheoryState();
  resetPracticeState();
  renderModuleBrowser();
  await loadProgress();

  const firstTheoryModule = subject.modules.find((module) => module.type === 'theory');
  if (firstTheoryModule) {
    await loadTheoryModule(firstTheoryModule);
  }
}

async function login(username, password) {
  const payload = await api('/api/auth/login', {
    method: 'POST',
    body: JSON.stringify({
      username,
      password,
      target: 'student'
    })
  });

  setAuthenticatedView(payload.user);
  await initializeStudyApp();
}

async function initializeStudyApp() {
  const subjects = await api('/api/subjects');
  state.subjects = subjects;
  renderSubjects();

  if (subjects.length) {
    await selectSubject(subjects[0].slug);
  }
}

async function initialize() {
  const session = await api('/api/auth/session');
  if (!session.user) {
    setLoggedOutView();
    return;
  }

  setAuthenticatedView(session.user);
  await initializeStudyApp();
}

loginForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  const formData = new FormData(loginForm);

  try {
    await login(formData.get('username'), formData.get('password'));
    loginForm.reset();
  } catch (error) {
    loginFeedback.textContent = error.message;
  }
});

logoutButton.addEventListener('click', async () => {
  await api('/api/auth/logout', {
    method: 'POST',
    body: JSON.stringify({})
  });

  setLoggedOutView('Je bent uitgelogd.');
  state.subjects = [];
});

initialize().catch((error) => {
  if (error.status === 401) {
    setLoggedOutView('Log in om verder te gaan.');
    return;
  }

  subjectDescription.textContent = `Initialiseren mislukt: ${error.message}`;
});
