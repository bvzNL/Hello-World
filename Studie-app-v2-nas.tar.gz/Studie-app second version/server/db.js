import fs from 'node:fs';
import path from 'node:path';
import Database from 'better-sqlite3';
import { hashPassword } from './auth.js';

const projectRoot = path.resolve(process.cwd());
const dataDir = path.join(projectRoot, 'data');
const dbPath = path.join(dataDir, 'studie-app.db');

function ensureDataDir() {
  fs.mkdirSync(dataDir, { recursive: true });
}

function addColumnIfMissing(db, tableName, columnName, definition) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  const exists = columns.some((column) => column.name === columnName);
  if (!exists) {
    db.exec(`ALTER TABLE ${tableName} ADD COLUMN ${columnName} ${definition}`);
  }
}

function hasColumn(db, tableName, columnName) {
  const columns = db.prepare(`PRAGMA table_info(${tableName})`).all();
  return columns.some((column) => column.name === columnName);
}

function rebuildTableWithoutSourcePath(db, tableName, createSql, columnList) {
  if (!hasColumn(db, tableName, 'source_path')) {
    return;
  }

  const tempName = `${tableName}_clean`;
  db.exec(`
    ${createSql.replace(`CREATE TABLE ${tableName}`, `CREATE TABLE ${tempName}`)};
    INSERT INTO ${tempName} (${columnList.join(', ')})
    SELECT ${columnList.join(', ')}
    FROM ${tableName};
    DROP TABLE ${tableName};
    ALTER TABLE ${tempName} RENAME TO ${tableName};
  `);
}

function removeLegacySourcePathColumns(db) {
  rebuildTableWithoutSourcePath(
    db,
    'subjects',
    `CREATE TABLE subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      accent_color TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    )`,
    ['id', 'slug', 'title', 'description', 'accent_color', 'created_at', 'updated_at']
  );

  rebuildTableWithoutSourcePath(
    db,
    'modules',
    `CREATE TABLE modules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('theory', 'practice', 'assessment')),
      topic TEXT NOT NULL,
      summary TEXT NOT NULL,
      position INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    )`,
    ['id', 'subject_id', 'slug', 'title', 'type', 'topic', 'summary', 'position', 'created_at', 'updated_at']
  );

  rebuildTableWithoutSourcePath(
    db,
    'theory_sections',
    `CREATE TABLE theory_sections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      module_id INTEGER NOT NULL,
      heading TEXT NOT NULL,
      body_markdown TEXT NOT NULL,
      position INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    )`,
    ['id', 'module_id', 'heading', 'body_markdown', 'position', 'created_at', 'updated_at']
  );

  rebuildTableWithoutSourcePath(
    db,
    'questions',
    `CREATE TABLE questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      module_id INTEGER NOT NULL,
      topic TEXT NOT NULL,
      kind TEXT NOT NULL CHECK(kind IN ('open', 'multiple_choice')),
      prompt TEXT NOT NULL,
      explanation TEXT NOT NULL,
      difficulty INTEGER NOT NULL DEFAULT 1,
      correct_answer TEXT NOT NULL,
      options_json TEXT NOT NULL DEFAULT '[]',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    )`,
    ['id', 'module_id', 'topic', 'kind', 'prompt', 'explanation', 'difficulty', 'correct_answer', 'options_json', 'is_active', 'created_at', 'updated_at']
  );
}

export function defaultUsers() {
  return [
    {
      username: process.env.ADMIN_USERNAME || 'admin',
      password: process.env.ADMIN_PASSWORD || 'Admin123!',
      displayName: process.env.ADMIN_DISPLAY_NAME || 'Beheerder',
      role: 'admin'
    },
    {
      username: process.env.STUDENT_USERNAME || 'leerling',
      password: process.env.STUDENT_PASSWORD || 'Leerling123!',
      displayName: process.env.STUDENT_DISPLAY_NAME || 'Leerling',
      role: 'student'
    }
  ];
}

export function ensureDefaultUsers(db) {
  const selectUser = db.prepare('SELECT id FROM users WHERE username = ?');
  const insertUser = db.prepare(`
    INSERT INTO users (username, password_hash, display_name, role, is_active)
    VALUES (?, ?, ?, ?, 1)
  `);

  defaultUsers().forEach((user) => {
    const existing = selectUser.get(user.username);
    if (existing) {
      return;
    }

    insertUser.run(
      user.username,
      hashPassword(user.password),
      user.displayName,
      user.role
    );
  });
}

export function initializeDatabase() {
  ensureDataDir();
  const db = new Database(dbPath);
  db.pragma('journal_mode = WAL');
  db.pragma('foreign_keys = ON');

  db.exec(`
    CREATE TABLE IF NOT EXISTS subjects (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      accent_color TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS modules (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      slug TEXT NOT NULL UNIQUE,
      title TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('theory', 'practice', 'assessment')),
      topic TEXT NOT NULL,
      summary TEXT NOT NULL,
      position INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS theory_sections (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      module_id INTEGER NOT NULL,
      heading TEXT NOT NULL,
      body_markdown TEXT NOT NULL,
      position INTEGER NOT NULL DEFAULT 0,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS questions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      module_id INTEGER NOT NULL,
      topic TEXT NOT NULL,
      kind TEXT NOT NULL CHECK(kind IN ('open', 'multiple_choice')),
      prompt TEXT NOT NULL,
      explanation TEXT NOT NULL,
      difficulty INTEGER NOT NULL DEFAULT 1,
      correct_answer TEXT NOT NULL,
      options_json TEXT NOT NULL DEFAULT '[]',
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS attempts (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id TEXT NOT NULL,
      question_id INTEGER NOT NULL,
      subject_slug TEXT NOT NULL,
      topic TEXT NOT NULL,
      is_correct INTEGER NOT NULL,
      answer_text TEXT,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (question_id) REFERENCES questions(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      username TEXT NOT NULL UNIQUE,
      password_hash TEXT NOT NULL,
      display_name TEXT NOT NULL,
      role TEXT NOT NULL CHECK(role IN ('admin', 'student')),
      is_active INTEGER NOT NULL DEFAULT 1,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS sessions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER NOT NULL,
      token TEXT NOT NULL UNIQUE,
      expires_at TEXT NOT NULL,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    );

    CREATE TABLE IF NOT EXISTS imports (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      subject_id INTEGER NOT NULL,
      title TEXT NOT NULL,
      module_slug TEXT NOT NULL,
      module_topic TEXT NOT NULL,
      module_summary TEXT NOT NULL,
      original_filename TEXT NOT NULL,
      stored_filename TEXT NOT NULL,
      mime_type TEXT NOT NULL,
      source_format TEXT NOT NULL CHECK(source_format IN ('txt', 'docx')),
      raw_text TEXT NOT NULL,
      suggested_sections_json TEXT NOT NULL DEFAULT '[]',
      status TEXT NOT NULL DEFAULT 'uploaded' CHECK(status IN ('uploaded', 'imported')),
      imported_module_id INTEGER,
      created_at TEXT DEFAULT CURRENT_TIMESTAMP,
      updated_at TEXT DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (subject_id) REFERENCES subjects(id) ON DELETE CASCADE,
      FOREIGN KEY (imported_module_id) REFERENCES modules(id) ON DELETE SET NULL
    );
  `);

  addColumnIfMissing(db, 'subjects', 'updated_at', 'TEXT DEFAULT CURRENT_TIMESTAMP');
  addColumnIfMissing(db, 'modules', 'updated_at', 'TEXT DEFAULT CURRENT_TIMESTAMP');
  addColumnIfMissing(db, 'theory_sections', 'updated_at', 'TEXT DEFAULT CURRENT_TIMESTAMP');
  addColumnIfMissing(db, 'questions', 'updated_at', 'TEXT DEFAULT CURRENT_TIMESTAMP');
  addColumnIfMissing(db, 'imports', 'updated_at', 'TEXT DEFAULT CURRENT_TIMESTAMP');
  addColumnIfMissing(db, 'users', 'updated_at', 'TEXT DEFAULT CURRENT_TIMESTAMP');
  removeLegacySourcePathColumns(db);
  ensureDefaultUsers(db);

  return db;
}
