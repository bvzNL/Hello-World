import fs from 'node:fs';
import path from 'node:path';

function rows(db, sql) {
  return db.prepare(sql).all();
}

export function exportSnapshot(db) {
  return {
    version: 1,
    exportedAt: new Date().toISOString(),
    subjects: rows(db, `
      SELECT id, slug, title, description, accent_color AS accentColor
      FROM subjects
      ORDER BY id
    `),
    modules: rows(db, `
      SELECT id, subject_id AS subjectId, slug, title, type, topic, summary, position
      FROM modules
      ORDER BY id
    `),
    theorySections: rows(db, `
      SELECT id, module_id AS moduleId, heading, body_markdown AS body, position
      FROM theory_sections
      ORDER BY id
    `),
    questions: rows(db, `
      SELECT
        id,
        module_id AS moduleId,
        topic,
        kind,
        prompt,
        explanation,
        difficulty,
        correct_answer AS correctAnswer,
        options_json AS optionsJson,
        is_active AS isActive
      FROM questions
      ORDER BY id
    `)
  };
}

export function writeSnapshot(filePath, snapshot) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(snapshot, null, 2)}\n`);
}

export function readSnapshot(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

export function importSnapshot(db, snapshot) {
  const transaction = db.transaction(() => {
    db.prepare('DELETE FROM sessions').run();
    db.prepare('DELETE FROM attempts').run();
    db.prepare('DELETE FROM imports').run();
    db.prepare('DELETE FROM theory_sections').run();
    db.prepare('DELETE FROM questions').run();
    db.prepare('DELETE FROM modules').run();
    db.prepare('DELETE FROM subjects').run();

    db.prepare("DELETE FROM sqlite_sequence WHERE name IN ('subjects', 'modules', 'theory_sections', 'questions', 'attempts', 'imports')").run();

    const insertSubject = db.prepare(`
      INSERT INTO subjects (id, slug, title, description, accent_color)
      VALUES (?, ?, ?, ?, ?)
    `);
    const insertModule = db.prepare(`
      INSERT INTO modules (id, subject_id, slug, title, type, topic, summary, position)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const insertTheory = db.prepare(`
      INSERT INTO theory_sections (id, module_id, heading, body_markdown, position)
      VALUES (?, ?, ?, ?, ?)
    `);
    const insertQuestion = db.prepare(`
      INSERT INTO questions (id, module_id, topic, kind, prompt, explanation, difficulty, correct_answer, options_json, is_active)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    snapshot.subjects.forEach((subject) => {
      insertSubject.run(subject.id, subject.slug, subject.title, subject.description, subject.accentColor);
    });

    snapshot.modules.forEach((module) => {
      insertModule.run(module.id, module.subjectId, module.slug, module.title, module.type, module.topic, module.summary, module.position);
    });

    snapshot.theorySections.forEach((section) => {
      insertTheory.run(section.id, section.moduleId, section.heading, section.body, section.position);
    });

    snapshot.questions.forEach((question) => {
      insertQuestion.run(
        question.id,
        question.moduleId,
        question.topic,
        question.kind,
        question.prompt,
        question.explanation,
        question.difficulty,
        question.correctAnswer,
        question.optionsJson,
        question.isActive
      );
    });
  });

  transaction();
}
