import path from 'node:path';
import { initializeDatabase, defaultUsers, ensureDefaultUsers } from '../server/db.js';
import { importSnapshot, readSnapshot } from '../server/seed.js';

const inputPath = path.resolve(process.cwd(), 'seeds', 'base-seed.json');
const db = initializeDatabase();
const snapshot = readSnapshot(inputPath);

importSnapshot(db, snapshot);
ensureDefaultUsers(db);

console.log(`Database gevuld vanuit ${inputPath}`);
console.log('Standaardaccounts:');
defaultUsers().forEach((user) => {
  console.log(`- ${user.role}: ${user.username}`);
});
