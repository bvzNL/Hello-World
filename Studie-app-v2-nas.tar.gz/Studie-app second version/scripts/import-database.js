import path from 'node:path';
import { initializeDatabase, ensureDefaultUsers } from '../server/db.js';
import { importSnapshot, readSnapshot } from '../server/seed.js';

const inputPath = process.argv[2]
  ? path.resolve(process.argv[2])
  : path.resolve(process.cwd(), 'seeds', 'base-seed.json');

const db = initializeDatabase();
const snapshot = readSnapshot(inputPath);

importSnapshot(db, snapshot);
ensureDefaultUsers(db);

console.log(`Database geïmporteerd vanuit ${inputPath}`);
