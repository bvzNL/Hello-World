import crypto from 'node:crypto';

const SESSION_COOKIE = 'studie_app_session';
const SESSION_TTL_MS = 1000 * 60 * 60 * 24 * 14;

function base64Url(value) {
  return Buffer.from(value).toString('base64url');
}

export function hashPassword(password, salt = crypto.randomBytes(16).toString('hex')) {
  const passwordHash = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return `${salt}:${passwordHash}`;
}

export function verifyPassword(password, storedHash) {
  const [salt, existingHash] = String(storedHash || '').split(':');
  if (!salt || !existingHash) {
    return false;
  }

  const candidate = crypto.scryptSync(String(password), salt, 64).toString('hex');
  return crypto.timingSafeEqual(Buffer.from(existingHash, 'hex'), Buffer.from(candidate, 'hex'));
}

export function createSessionToken() {
  return base64Url(crypto.randomBytes(48));
}

export function createSessionExpiry() {
  return new Date(Date.now() + SESSION_TTL_MS).toISOString();
}

export function parseCookies(headerValue) {
  return String(headerValue || '')
    .split(';')
    .map((part) => part.trim())
    .filter(Boolean)
    .reduce((cookies, part) => {
      const separatorIndex = part.indexOf('=');
      if (separatorIndex === -1) {
        return cookies;
      }

      const key = part.slice(0, separatorIndex).trim();
      const value = decodeURIComponent(part.slice(separatorIndex + 1).trim());
      cookies[key] = value;
      return cookies;
    }, {});
}

export function sessionCookieValue(token, maxAgeSeconds = Math.floor(SESSION_TTL_MS / 1000)) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAgeSeconds}`;
}

export function clearSessionCookieValue() {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

export function getSessionTokenFromRequest(request) {
  const cookies = parseCookies(request.headers.cookie);
  return cookies[SESSION_COOKIE] || '';
}

export function publicUser(user) {
  if (!user) {
    return null;
  }

  return {
    id: user.id,
    username: user.username,
    displayName: user.display_name,
    role: user.role
  };
}
